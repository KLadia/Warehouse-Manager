CRICK.E.T. WAREHOUSE MANAGEMENT

Thanks for choosing Crick.E.T. for all your warehouse needs! This system will allow you to keep track of employees, inventory data, imports and exports, and scheduling. The system features essential functionality for creating export labels, tracking incoming packages, and alloating employee tasks. See below for installation and build instructions to get started.

INSTALLING
So far, you’ve downloaded the compressed file containing the read me, several txt files and a jar file. !!! It is imperative that you keep all of these things int he same folder !!! You may place this file (README) in a separate location if you wish, but it is not advised. Save this folder and the entirety of it’s contents to an easily accessible location on your computer like the desktop.

RUNNING THE PROGRAM
To run the Crick.E.T. Warehouse Management System, open the folder “Cricket Warehouse Manager” and double click the file titled “WarehouseManagementSystem.jar”. The Crick.E.T. login screen will launch. This may take a few seconds.

AUTHORS
Andrew Aaran - GUI and backend
Chelsea Atkins - backend and GUI
Hunter Chagnon - manager and web development
Daniela Fuenzalida - CSS and SQA
Kristin Ladia - SQA and backend
Esteban Tavel - GUI and UML

ACKNOWLEDGEMENTS
Thank you Dr. Koufakou for your guidance and assurance.
Special thanks to Shelby for answering our late night questions on how to get buttons to work.
Thank you Esteban, for letting us use your face as the mascot.