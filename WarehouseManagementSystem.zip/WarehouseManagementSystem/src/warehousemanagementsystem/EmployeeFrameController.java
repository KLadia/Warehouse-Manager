/* 
 * employeeframecontroller.java
 *
 * Frame for the employee. Contains the dashboard tab, import and export tabs,
 * and employee tools tab. The dashboard is the first tab you see upon entering.
 * It contains user specific tasks sorted by today and upcoming (up to +one week).
 * They can also see announcements created by the manager and access the popup.
 * Import and export tab feature accordion and titled panes to display dropdowns
 * of UPC and tracking number based information. Tools tab allows employee to 
 * order new product or create a new export label (seperate frames).
 *
 * @author : andrewaaran (Sep 15 2017)
 *
 * @SQA    : kristinladia (tested Oct 3 2017) - scrollbox for annoncements
 *           gets really long... create a new frame for viewing all announcements?
 * @SQA    : kristinladia (tested on Oct 20) - nothing happens when task is checked
 * @SQA    : danielafuenzalida (tested on Dec 1) - tasks do not work for single 
 *           digit days or months
 * @SQA    : danielafuenzalida (last tested Dec 3 2017)
 *
 * @update : andrewaaran (Oct 21 2017) - added announcements popup
 * @update : chelseaatkins (Oct 21 2017) - added action handler for checking task
 * @update : chelseaatkins (Dec 2 2017) - fixed single digit month/day tasks
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EmployeeFrameController implements Initializable {
    
    // access username entered during login to set user
    String user = LoginFrameController.enteredUsernameEmp;
    
    // keep track of tasks added and tasks completed to show % in manager dash
    static double taskCount;
    static double taskComplete;
    
    @FXML
    private Label title; // shows welcome message with username
    
    @FXML
    private ScrollPane todayScroller; // allows today tasks to scroll
    
    @FXML
    private VBox today; // holds checkboxes for tasks
    
    @FXML
    private ScrollPane upcomingScroller; // allows upcoming tasks to scroll
    
    @FXML
    private VBox upcoming; // holds checkboxes for upcoming tasks
    
    @FXML
    private Label nextImport; // setText for next upcoming import date
    
    @FXML
    private Label nextExport; // setText for next upcoming export date
    
    @FXML
    private Label announcements; // setText for announcements in file
    
    @FXML
    private Accordion imports; // holds title panes for imports
    
    @FXML
    private Accordion exports; // holds title panes for exports
    
    
    // send user back to login frame with logout message popup on action
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        // @daniela : add css style sheets
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        logoutFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    // create a new scene for the order new product frame
    @FXML
    private void handleOrderNewProduct(ActionEvent event) throws IOException {
        Parent orderProductFrame = FXMLLoader.load(getClass().getResource("OrderProductFrame.fxml"));
        Scene orderProductScene = new Scene(orderProductFrame);
        // @daniela : add css style sheets
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        orderProductScene.getStylesheets().add(css);
        // end css resource
        Stage getOrderProductFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getOrderProductFrame.setScene(orderProductScene);
        getOrderProductFrame.show();
    }
    
    // create a new scene for creating export labels
    @FXML
    private void handleCreateExportLabel(ActionEvent event) throws IOException {
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("CreateLabelFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        // @daniela : add css style sheets
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        // end css resource
        Stage getCreateLabelFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateLabelFrame.setScene(createLabelScene);
        getCreateLabelFrame.show();
    }
    
    // this creates a popup instead of a new scene for viewing all announcements
    @FXML
    private void handleViewAllAnnouncements(ActionEvent event) throws IOException {
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ViewAllAnnouncements.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        // @daniela : add css style sheets
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        // end css resource
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    // sample method for getting the nearest date by calculating number of days away
    public static long getDifferenceDays(Date d1, Date d2) {
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }
    
    // execute this method everytime window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // set welcome message text in title
        title.setText("Welcome, " + user); // user accessed from loginframecontroller
        
        // set scroller backgrounds to transparent
        todayScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        upcomingScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        
        // updates announcements on employee dashboard
        File AnnouncementsData = new File("Announcements.txt");
        
        try{
            // set the file reader to read through the announcements file
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            String lineFind; // used for reading through file
            
            // this string will be used for concatenation and a label will have the text
            // set to this string to display the announcements
            String storeAnnouncements = "";
            
            // temporarily stores and formats all announcements from file
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) { // reading through file
                temp.add(lineFind); // add each line in the file to array list
            }
            // search through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent announcement at the top
                storeAnnouncements += (temp.get(i) + System.lineSeparator() + System.lineSeparator());
                announcements.setText(storeAnnouncements); // set label text
            }
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } 
        
        // for updating the imports tab
        File importsData = new File("Imports.txt"); // file to read from
        try{
            // create file reader and buffered reader
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
            
            // store each line in the file in a new variable
            String lineFind; // this is UPC
            String line2; // this is the date
            String line3; // this is the description
            String line4; // this is the user and time
            
            // create an array of titled panes to dynamically add to as more
            // imports are added to the accordion
            List<TitledPane> panes = new ArrayList<TitledPane>();
            
            // read each line in the file
            while((lineFind = readData.readLine()) != null) {
                
                // store each line in the file as a variable
                line2 = readData.readLine();
                line3 = readData.readLine();
                line4 = readData.readLine();
                
                // add information to each pane
                panes.add(new TitledPane(lineFind, new Label(line2
                        + System.lineSeparator() + line3 + 
                        System.lineSeparator() + line4)));
            }
            
            // add all panes to the imports accordion
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } 
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt"); // file to read from
        
        try {
            // file reader to read exports.txt
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX; // variable used to read through the file
            
            // array list for storing the export titledpanes
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            
            // read through file until there are no lines left
            while((lineX = readExportsData.readLine()) != null) {
                // add information to each newPane
                // these aren't stored as vairables, just read each new line inside
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            // add all export titledpanes to the exports accordion
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } 
        
        // for updating the tasks section
        File tasksData = new File("Tasks.txt"); // file to read from
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("M/d/yyyy");
        LocalDate localDate = LocalDate.now(); // today's date
        LocalDate weekToday = localDate.plusWeeks(1); // next week
       
        // turning date into string usinf formatter d
        String date = d.format(localDate);
        
        // array lsits of check boxes to contain the tasks and upcoming tasks
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        

        try{
            // reading the file tasks.txt to add checkboxes
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
            
            String liner; // variable to read through file
            LocalDate dateInFile; // find the string date stored in the file
            
            // read the file until there are no lines left
            while((liner = readTasksData.readLine()) != null) {
               
                try { // try block to parsing string to local date
                    dateInFile = LocalDate.parse(liner, d); // parse string
                    
                    // check if the parsed date is the same as today's date
                    if(date.equals(liner)) { // if yes read user
                        liner = readTasksData.readLine(); // read next line if yes
                        
                        // check if the read user in file is the same as current user
                        if(liner.equals(user)) { // if yes read next line
                            liner = readTasksData.readLine(); // this line contains task data
                            tasks.add(new CheckBox(liner)); // put task data in checkbox
                            
                            // this part is used to calculate precentage on manager frame
                            taskCount++; // increment the total number of tasks
                        }
                    }
                    // this means that the date is not today
                    else { 
                        // check if the parsed date is within the next week
                        if(localDate.compareTo(dateInFile) <= 0 && dateInFile.compareTo(weekToday) < 0){
                            liner = readTasksData.readLine(); // if yes read next line (user)
                            
                            // check if the next line is equal to the current user
                            if(liner.equals(user)) {
                                liner = readTasksData.readLine(); // this is the task info
                                // add task info to an upcoming checkbox
                                upcomingTasks.add(new CheckBox(liner));
                            }
                        }
                    }
                } catch(Exception e) {
                    System.out.println(e); // no further handler necessary
                } // end try-catch block for parsing local date and string
            } // end reading through tasks file
            
            // add all tasks from checkbox arraylist to today vbox
            today.getChildren().addAll(tasks);
            
            // add all upmcoming tasks to upcoming vbox
            upcoming.getChildren().addAll(upcomingTasks);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } 
        
        // TASK ACCTION HANDLERS - BEGIN LOTS OF CODE
        // @chelsea : see me if you need an explanation of how this works...
        
        // handles the checking and unchecking of tasks
        // store date, user, and task details in an array list
        // accessed to add tasks back in if user changes their mind and unchecks
        List<String> holdTaskInfo = new ArrayList<String>();
        
        // define event handlers for a dynamic list of checkboxes
        EventHandler checked = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) { // action handler (event is checking box)
                for (int i = 0; i < tasks.size(); i++) {
                    String initialTask = tasks.get(i).getText(); // get text of a checkbox
                    
                    // check is a task is selected
                    if (event.getSource() == tasks.get(i) && tasks.get(i).isSelected()) {
                        
                        // this removes tasks
                        File inputFile = new File("Tasks.txt");
                        
                        // temporary file used to handle the removal of a task
                        File tempFile = new File("temp.txt");
                        
                        // task is checked, increment tasks complete
                        taskComplete++;
            
                        try {
                            // reader and writer to edit tasks.txt
                            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
        
                            // find initial task to remove based on task text
                            String firstLine; // date
                            
                            // read each line in the file until null
                            while((firstLine = reader.readLine()) != null) {
                                
                                // hold info in case user changes their mind
                                holdTaskInfo.add(firstLine);
                                
                                // trim newline when comparing with initial task
                                String secondLine = reader.readLine(); // assigned to
                                
                                // hold info in case user changes their mind
                                holdTaskInfo.add(secondLine);
                                
                                String thirdLine = reader.readLine(); // task details
                                
                                // hold info in case user changes their mind
                                holdTaskInfo.add(thirdLine);
                                
                                // trim lines
                                String trimmedLine = thirdLine.trim();
                                
                                // continue trim after comparison
                                if(trimmedLine.equals(initialTask)) continue;
                                
                                // overwrite the date, user, and task info and remove
                                writer.write(firstLine + System.getProperty("line.separator") + 
                                    secondLine + System.getProperty("line.separator") + thirdLine + 
                                    System.getProperty("line.separator"));
                            
                            }
                            writer.close(); // close writer
                            reader.close(); // close reader
                            
                            // rename the temporary file to tasks.txt
                            boolean successful = tempFile.renameTo(inputFile);
                            
                        } catch (IOException e) {
                            System.out.println(e); // no further handler necessary
                        } // end try-catch for removing info from tasks.txt
                        
                        // add notification text to file (for manager notification)
                        File notificationFile = new File("Notifications.txt");
                        
                        try{
                            // file writer to append new notifications
                            FileWriter addToNotification = new FileWriter(notificationFile, true);
                            BufferedWriter addNotification = new BufferedWriter(addToNotification);
                            
                            // get who has completed the task as well as the details of the task
                            addNotification.append(user + " has completed " + initialTask);
                            addNotification.newLine();
                            addNotification.close();  // close writer
                            
                        } catch (IOException e) {
                            System.out.println(e); // no further handler necessary
                        } // end try-catch for writing notifications
                        
                    } // end task is selected if block
                    // now the task is being deselected so we'll add the task back to file
                    else if (event.getSource() == tasks.get(i) && !tasks.get(i).isSelected()) {
                       
                        // decrement task complete because user has unchecked it
                        taskComplete--;
                        
                        File inputFile = new File("Tasks.txt"); // file to write to
                        
                        try{
                            // buffered and file writers for appending info
                            FileWriter addToTasks = new FileWriter(inputFile, true);
                            BufferedWriter undoSelect = new BufferedWriter(addToTasks);
                            
                            // selected task info was previously stored in holdTaskInfo
                            // we'll access this array list to add that task back to the file
                            for (int j = 0; j < holdTaskInfo.size(); j++) {
                                
                                // find the initially selected task in holdTaskInfo
                                // search backwards in the array list to find the
                                // rest of the task info
                                if(initialTask.equals(holdTaskInfo.get(j))) {
                                    // appending line by line
                                    undoSelect.append(holdTaskInfo.get(j - 2));
                                    undoSelect.newLine();
                                    undoSelect.append(holdTaskInfo.get(j - 1));
                                    undoSelect.newLine();
                                    undoSelect.append(holdTaskInfo.get(j));
                                    undoSelect.newLine();
                                    break; // break the loop, we're done
                                }
                            }
                            
                            undoSelect.close(); // close writer
                            
                        } catch (IOException e) {
                            System.out.println(e); // no further handler necessary
                        } // end try-catch for unchecking a selected task
                        
                        // add notification text to send (for manager notification)
                        File notificationFile = new File("Notifications.txt");
                        
                        // now we must let the manager know that the employee
                        // has unselected that task
                        try{
                            // writers to append information to notifications.txt
                            FileWriter addToNotification = new FileWriter(notificationFile, true);
                            BufferedWriter addNotification = new BufferedWriter(addToNotification);
                            
                            // get the information from the user as well as task info
                            addNotification.append(user + " has unchecked " + initialTask);
                            addNotification.newLine(); // store on new line
                            addNotification.close(); // close writer
                            
                        } catch (IOException e) {
                            System.out.println(e); // no further handler necessary
                        } // end try-catch for updating manager notifications
                        
                    } // end task is unselected after being selected else-if block
                } // end tasks.size() for loop
            } // end handle method
        }; // end event handler
        
        
        // registering action handlers for every check box in tasks and upcoming
        for (int i = 0; i < tasks.size(); i++) {
            tasks.get(i).setOnAction(checked);
        }
        for (int i = 0; i < upcomingTasks.size(); i++) {
            upcomingTasks.get(i).setOnAction(checked);
        }
    } // end method initialize
} // end EmployeeFrameController
