/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class EmployeeFrameController implements Initializable {
    
    @FXML
    private Accordion imports;
    
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
    }
    
    @FXML
    private void handleOrderNewProduct(ActionEvent event) throws IOException {
        Parent orderProductFrame = FXMLLoader.load(getClass().getResource("OrderProductFrame.fxml"));
        Scene orderProductScene = new Scene(orderProductFrame);
        Stage getOrderProductFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getOrderProductFrame.setScene(orderProductScene);
        getOrderProductFrame.show();
    }
    
    @FXML
    private void handleCreateExportLabel(ActionEvent event) throws IOException {
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("CreateLabelFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        Stage getCreateLabelFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateLabelFrame.setScene(createLabelScene);
        getCreateLabelFrame.show();
    }
    
    // intialize the controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        // for adding import dropdowns to the imports tab
        // TitledPane tp = new TitledPane(); // can hold up to 50 imports
        // imports.getChildren().addAll(tp[i]); 
        // REFERENCE tp[0].setText("Title of pane");
        
        String upcs; 
        GridPane grid = new GridPane();
        File importsData = new File("Imports.txt");
        
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            String nextLineFind;
            
            List<String> titles = new ArrayList<String>();
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
                titles.add(lineFind);
                panes.add(new TitledPane(lineFind, null));
                lineFind = readData.readLine();
                lineFind = readData.readLine();
                
            }
            
            imports.getPanes().addAll(panes); 
            
            
            /*String titles[] = list.toArray(new String[(list.size())/3]);
            TitledPane tp[] = new TitledPane[titles.length];
            List<String> list = new ArrayList<String>();
            for(int i = 0; i < list.size(); i++) {
                imports.getChildren().add(tp[i]); 
            }
            //tp.setText(titles[0]);
            //imports.getChildren().add(tp); 
            /*nextLineFind = readData.readLine();
            tp.setText(nextLineFind);
            imports.getChildren().addAll(tp); 
            
            nextLineFind = readData.readLine();
            grid.setVgap(4);
            grid.add(new Label("Date: " + nextLineFind), 0, 0);
            tp.setContent(grid);
            
            nextLineFind = readData.readLine();
            grid.add(new Label("Description: " + nextLineFind), 0, 1);
            tp.setContent(grid);*/
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        // TODO adding exports dropdowns to the exports tab
    }    
    
}
