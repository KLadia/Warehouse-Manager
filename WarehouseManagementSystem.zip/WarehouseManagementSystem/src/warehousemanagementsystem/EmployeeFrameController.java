package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EmployeeFrameController implements Initializable {
    
    // access username entered during login to set user
    String user = LoginFrameController.enteredUsernameEmp;
    
    // keep track of tasks added and tasks completed to show % in manager dash
    static double taskCount;
    static double taskComplete;
    
    @FXML
    private Label title; // shows welcome message with username
    
    @FXML
    private ScrollPane todayScroller; // allows today tasks to scroll
    
    @FXML
    private VBox today; // holds checkboxes for tasks
    
    @FXML
    private ScrollPane upcomingScroller; // allows upcoming tasks to scroll
    
    @FXML
    private VBox upcoming; // holds checkboxes for upcoming tasks
    
    @FXML
    private Label nextImport; // setText for next upcoming import date
    
    @FXML
    private Label nextExport; // setText for next upcoming export date
    
    @FXML
    private Label announcements; // setText for announcements in file
    
    @FXML
    private Accordion imports; // holds title panes for imports
    
    @FXML
    private Accordion exports; // holds title panes for exports
    
    
    // send user back to login frame with logout message popup on action
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        logoutFrameScene.getStylesheets().add(css);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    // create a new scene for the order new product frame
    @FXML
    private void handleOrderNewProduct(ActionEvent event) throws IOException {
        Parent orderProductFrame = FXMLLoader.load(getClass().getResource("OrderProductFrame.fxml"));
        Scene orderProductScene = new Scene(orderProductFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        orderProductScene.getStylesheets().add(css);
        Stage getOrderProductFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getOrderProductFrame.setScene(orderProductScene);
        getOrderProductFrame.show();
    }
    
    // create a new scene for creating export labels
    @FXML
    private void handleCreateExportLabel(ActionEvent event) throws IOException {
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("CreateLabelFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        Stage getCreateLabelFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateLabelFrame.setScene(createLabelScene);
        getCreateLabelFrame.show();
    }
    
    // this creates a popup instead of a new scene
    @FXML
    private void handleViewAllAnnouncements(ActionEvent event) throws IOException {
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ViewAllAnnouncements.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    public static long getDifferenceDays(Date d1, Date d2) {
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }
    
    // execute this method everytime window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // set welcome message text in title
        title.setText("Welcome, " + user);
        
        // set scroller backgrounds to transparent
        todayScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        upcomingScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        
        // updates announcements on employee dashboard
        File AnnouncementsData = new File("Announcements.txt");
        
        try{
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            String lineFind; // used for reading through file
            String storeAnnouncements = "";
            
            // temporarily stores and formats all announcements from file
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) { // reading through file
                temp.add(lineFind); // add each line in the file to array list
            }
            // search through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent announcement at the top
                storeAnnouncements += (temp.get(i) + System.lineSeparator() + System.lineSeparator());
                announcements.setText(storeAnnouncements); // set label text
            }
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the imports tab
        File importsData = new File("Imports.txt");
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
            
            // store each line in the file in a new variable
            String lineFind;
            String line2;
            String line3;
            String line4;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
                line2 = readData.readLine();
                line3 = readData.readLine();
                line4 = readData.readLine();
                panes.add(new TitledPane(lineFind, new Label(line2
                        + System.lineSeparator() + line3 + 
                        System.lineSeparator() + line4)));
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the next import text on employee dash
        List<Date> tempDates = new ArrayList<Date>(); // for next import on dash
        DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
            
            String readLine;
            while((readLine = readData.readLine()) != null) {
                readLine = readData.readLine();
                tempDates.add(formatter.parse(readLine));
                readLine = readData.readLine();
                readLine = readData.readLine();
            }
            Date todaysDateIs = new Date();

            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        
        nextExport.setText("Test");
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt");
        
        try{
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX;
            
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            while((lineX = readExportsData.readLine()) != null) {
               
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the tasks section
        File tasksData = new File("Tasks.txt");
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("M/d/yyyy");
        LocalDate localDate = LocalDate.now(); // today's date
        LocalDate weekToday = localDate.plusWeeks(1); // next week
       
        // turning date into string
        String date = d.format(localDate);
        
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        

        try{
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
                
            String liner;
            LocalDate dateInFile;
            
            while((liner = readTasksData.readLine()) != null) {
               
                try {
                    dateInFile = LocalDate.parse(liner, d);
                    if(date.equals(liner)) {
                        liner = readTasksData.readLine();
                        if(liner.equals(user)) {
                            liner = readTasksData.readLine();
                            tasks.add(new CheckBox(liner));
                            taskCount++;
                        }
                    }
                    else {
                        if(localDate.compareTo(dateInFile) <= 0 && dateInFile.compareTo(weekToday) < 0){
                            liner = readTasksData.readLine();
                            if(liner.equals(user) || liner.equals("All Employees")) {
                                liner = readTasksData.readLine();
                                upcomingTasks.add(new CheckBox(liner));
                            }
                        }
                    }
                } catch(Exception e) {
                    System.out.println(e);
                } 
            }
            
            today.getChildren().addAll(tasks);
            upcoming.getChildren().addAll(upcomingTasks);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // handles the checking and unchecking of tasks
        // store date, user, and task details in an array list
        // accessed to add tasks back in if user changes their mind
        List<String> holdTaskInfo = new ArrayList<String>();
        
        // define event handlers for a dynamic list of checkboxes
        EventHandler checked = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) { // action handler (event is checking box)
                for (int i = 0; i < tasks.size(); i++) {
                    String initialTask = tasks.get(i).getText(); // get text of a checkbox
                    
                    if (event.getSource() == tasks.get(i) && tasks.get(i).isSelected()) {
                        
                        // this removes tasks
                        File inputFile = new File("Tasks.txt");
                        File tempFile = new File("temp.txt");
                        
                        taskComplete++;
            
                        try {
                            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
        
                            // find initial task to remove based on task text
                            String firstLine; // date
                            
                            while((firstLine = reader.readLine()) != null) {
                                holdTaskInfo.add(firstLine);
                                
                                // trim newline when comparing with initial task
                                String secondLine = reader.readLine(); // assigned to
                                holdTaskInfo.add(secondLine);
                                
                                String thirdLine = reader.readLine(); // task details
                                holdTaskInfo.add(thirdLine);
                                
                                String trimmedLine = thirdLine.trim();
                                
                                
                                if(trimmedLine.equals(initialTask)) continue;
                                
                                writer.write(firstLine + System.getProperty("line.separator") + 
                                    secondLine + System.getProperty("line.separator") + thirdLine + 
                                    System.getProperty("line.separator"));
                            
                            }
                            writer.close(); 
                            reader.close(); 
                            boolean successful = tempFile.renameTo(inputFile);
                            
                        } catch (IOException e) {
                            System.out.println(e);
                        }
                        
                        // add notification text to file (for manager notification)
                        File notificationFile = new File("Notifications.txt");
                        
                        try{
                            FileWriter addToNotification = new FileWriter(notificationFile, true);
                            BufferedWriter addNotification = new BufferedWriter(addToNotification);
                            
                            addNotification.append(user + " has completed " + initialTask);
                            addNotification.newLine();
                            addNotification.close(); 
                            
                        } catch (IOException e) {
                            System.out.println(e);
                        }
                        
                    } // end task is selected if block
                    // now the task is being deselected so we'll add the task back to file
                    else if (event.getSource() == tasks.get(i) && !tasks.get(i).isSelected()) {
                        taskComplete--;
                        File inputFile = new File("Tasks.txt");
                        
                        try{
                            FileWriter addToTasks = new FileWriter(inputFile, true);
                            BufferedWriter undoSelect = new BufferedWriter(addToTasks);
                            
                            for (int j = 0; j < holdTaskInfo.size(); j++) {
                                if(initialTask.equals(holdTaskInfo.get(j))) {
                                    undoSelect.append(holdTaskInfo.get(j - 2));
                                    undoSelect.newLine();
                                    undoSelect.append(holdTaskInfo.get(j - 1));
                                    undoSelect.newLine();
                                    undoSelect.append(holdTaskInfo.get(j));
                                    undoSelect.newLine();
                                    break;
                                }
                            }
                            
                            undoSelect.close(); 
                            
                        } catch (IOException e) {
                            System.out.println(e);
                        }
                        
                        // add notification text to send (for manager notification)
                        File notificationFile = new File("Notifications.txt");
                        
                        try{
                            FileWriter addToNotification = new FileWriter(notificationFile, true);
                            BufferedWriter addNotification = new BufferedWriter(addToNotification);
                            
                            addNotification.append(user + " has unchecked " + initialTask);
                            addNotification.newLine();
                            addNotification.close(); 
                            
                        } catch (IOException e) {
                            System.out.println(e);
                        }
                        
                    } // end task is unselected after being selected else-if block
                } // end tasks.size() for loop
            } // end handle method
        }; // end event handler
        
        
        // registering action handlers for every check box in tasks and upcoming
        for (int i = 0; i < tasks.size(); i++) {
            tasks.get(i).setOnAction(checked);
        }
        for (int i = 0; i < upcomingTasks.size(); i++) {
            upcomingTasks.get(i).setOnAction(checked);
        }
    }
} // end EmployeeFrameController
