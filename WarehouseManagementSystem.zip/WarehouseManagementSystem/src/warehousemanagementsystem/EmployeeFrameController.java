/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EmployeeFrameController implements Initializable {
    
    String user = LoginFrameController.enteredUsernameEmp;
    static List<Label> send = new ArrayList<Label>();
    static double taskCount;
    static double taskComplete;
    
    @FXML
    private Label title;
    
    @FXML
    private VBox today;
    
    @FXML
    private VBox upcoming;
    
    @FXML
    private Label nextImport;
    
    @FXML
    private Label nextExport;
    
    @FXML
    private Label announcements;
    
    @FXML
    private Accordion imports;
    
    @FXML
    private Accordion exports;
    
    @FXML
    private ScrollPane todayScroller;
    
    @FXML
    private ScrollPane upcomingScroller;
        
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @FXML
    private void handleOrderNewProduct(ActionEvent event) throws IOException {
        Parent orderProductFrame = FXMLLoader.load(getClass().getResource("OrderProductFrame.fxml"));
        Scene orderProductScene = new Scene(orderProductFrame);
        Stage getOrderProductFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getOrderProductFrame.setScene(orderProductScene);
        getOrderProductFrame.show();
    }
    
    @FXML
    private void handleCreateExportLabel(ActionEvent event) throws IOException {
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("CreateLabelFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        Stage getCreateLabelFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateLabelFrame.setScene(createLabelScene);
        getCreateLabelFrame.show();
    }
    
    // this creates a popup instead of a new scene
    @FXML
    private void handleViewAllAnnouncements(ActionEvent event) throws IOException {
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ViewAllAnnouncements.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    public static long getDifferenceDays(Date d1, Date d2) {
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }
    
    public Date getNearestDate(List<Date> dates, Date targetDate) {
        Date nearestDate = null;
        int index = 0;
        long prevDiff = -1;
        long targetTS = targetDate.getTime();
        for (int i = 0; i < dates.size(); i++) {
            Date date = dates.get(i);
            long currDiff = Math.abs(date.getTime() - targetTS);
            if (prevDiff == -1 || currDiff < prevDiff) {
                prevDiff = currDiff;
                nearestDate = date;
                index = i;
            }
        }
        return nearestDate;
    }
    
    // intialize the controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        title.setText("Welcome, " + user);
        todayScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        upcomingScroller.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        
        // for updating announcements on employee dashboard
        File AnnouncementsData = new File("Announcements.txt");
        
        try{
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            String lineFind;
            String storeAnnouncements = "";
            
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) {
                temp.add(lineFind);
                
            }
            for(int i = temp.size() - 1; i >= 0; i--) {
                storeAnnouncements += (temp.get(i) + System.lineSeparator() + System.lineSeparator());
                announcements.setText(storeAnnouncements);
            }
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the imports tab
        File importsData = new File("Imports.txt");
        List<Date> tempDates = new ArrayList<Date>(); // for import on dash
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            String line2;
            String line3;
            String line4;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
               line2 = readData.readLine();
               line3 = readData.readLine();
               line4 = readData.readLine();
                panes.add(new TitledPane(lineFind, new Label(line2
                        + System.lineSeparator() + line3 + 
                        System.lineSeparator() + line4)));
                
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt");
        
        try{
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX;
            
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            while((lineX = readExportsData.readLine()) != null) {
               
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the tasks section
        File tasksData = new File("Tasks.txt");
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate localDate = LocalDate.now();
        String date = d.format(localDate);
        Date regDate = java.sql.Date.valueOf(localDate);

        
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        
        try{
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
                
            String liner;
            DateTimeFormatter formatter;
            LocalDate linerDate;
            
            
            while((liner = readTasksData.readLine()) != null) {
                
                if(liner.isEmpty()) {
                    continue;
                }
                if(date.equals(liner)) {
                    liner = readTasksData.readLine();
                    if(liner.equals(user) || liner.equals("All Employees")) {
                        liner = readTasksData.readLine();
                        tasks.add(new CheckBox(liner));
                        taskCount++;
                    }
                }
                else {
                    if(liner.equals(user) || liner.equals("All Employees")) {
                        liner = readTasksData.readLine();
                        upcomingTasks.add(new CheckBox(liner));
                    }
                }
            }
            
            today.getChildren().addAll(tasks);
            upcoming.getChildren().addAll(upcomingTasks);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for handling checked off tasks
        // ISSUE: REFRESHING WINDOW brings task back??
            // possible fixes...
            // 1. remove that task from the file when it's checked
            // 1. write manager notifications to file and populate label
        EventHandler checked = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for (int i = 0; i < tasks.size(); i++) {
                    if (event.getSource() == tasks.get(i)) {
                        send.add(new Label(user + " has completed " + tasks.get(i).getText()
                              + System.lineSeparator()));
                        tasks.get(i).setVisible(false);
                        taskComplete++;
                    }
                }
                for (int i = 0; i < upcomingTasks.size(); i++) {
                    if (event.getSource() == upcomingTasks.get(i)) {
                        send.add(new Label(user + " has completed " + upcomingTasks.get(i).getText()
                              + System.lineSeparator()));
                        upcomingTasks.get(i).setVisible(false);
                    }
                }
            }
        };
        
        for (int i = 0; i < tasks.size(); i++) { // adding action handlers
            tasks.get(i).setOnAction(checked);
        }
        
        for (int i = 0; i < upcomingTasks.size(); i++) { // adding action handlers
            upcomingTasks.get(i).setOnAction(checked);
        }
    }    
    
}
