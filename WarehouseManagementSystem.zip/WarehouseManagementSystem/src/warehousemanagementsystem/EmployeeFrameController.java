/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import static java.awt.SystemColor.scrollbar;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class EmployeeFrameController implements Initializable {
    
    @FXML
    private VBox today;
    
    @FXML
    private Label nextImport;
    
    @FXML
    private Label nextExport;
    
    @FXML
    private Label announcements;
    
    @FXML
    private Accordion imports;
    
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
    }
    
    @FXML
    private void handleOrderNewProduct(ActionEvent event) throws IOException {
        Parent orderProductFrame = FXMLLoader.load(getClass().getResource("OrderProductFrame.fxml"));
        Scene orderProductScene = new Scene(orderProductFrame);
        Stage getOrderProductFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getOrderProductFrame.setScene(orderProductScene);
        getOrderProductFrame.show();
    }
    
    @FXML
    private void handleCreateExportLabel(ActionEvent event) throws IOException {
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("CreateLabelFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        Stage getCreateLabelFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateLabelFrame.setScene(createLabelScene);
        getCreateLabelFrame.show();
    }
    
    public static long getDifferenceDays(Date d1, Date d2) {
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }   
    // intialize the controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        // for updating announcements on employee dashboard
        File AnnouncementsData = new File("Announcements.txt");
        
        try{
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            String lineFind;
            String storeAnnouncements = "";
            
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) {
                temp.add(lineFind);
                
            }
            for(int i = temp.size() - 1; i >= 0; i--) {
                storeAnnouncements += (temp.get(i) + System.lineSeparator() + System.lineSeparator());
                announcements.setText(storeAnnouncements);
            }
            //announcements.setText(storeAnnouncements);
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        final String html1 = "<html><body style='width: ";
        final String html2 = "px'>";
        File importsData = new File("Imports.txt");
        
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
               
                panes.add(new TitledPane(lineFind, new Label(readData.readLine()
                        + System.lineSeparator() + readData.readLine())));
               
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        
        // TODO adding exports dropdowns to the exports tab
        
    }    
    
}
