/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import static warehousemanagementsystem.EmployeeFrameController.taskCount;

/**
 * FXML Controller class
 *
 * @author chelseaatkins
 */
public class ManagerFrameController implements Initializable {
    
    String user = LoginFrameController.enteredUsername;
    int percentage = (int) Math.round((EmployeeFrameController.taskComplete / 
            EmployeeFrameController.taskCount) * 100);
    
    @FXML
    private Label title;
    
    @FXML
    private Label percentComplete;
    
    @FXML
    private Label onDate;
    
    @FXML
    private Accordion imports;
    
    @FXML
    private Accordion exports;
    
    @FXML
    private VBox notifyManager;
    
    @FXML
    private Label notifications;
    
    @FXML
    private VBox today;
    
    @FXML
    private VBox upcoming;
    
    @FXML
    private ScrollPane todaysTasks;
    
    @FXML
    private ScrollPane nextTasks;
    
    @FXML
    private BarChart inventory;
    
    @FXML
    private CategoryAxis category;
    
    @FXML
    private NumberAxis numbers;
    
    @FXML
    private Label inventoryLastUpdate;
    
    @FXML
    private ProgressBar pb;
    
    
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @FXML
    private void handleLoadInventory(ActionEvent event) throws IOException {
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LoadInvetoryData.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @FXML
    private void handleCreateAccount(ActionEvent event) throws IOException {
        Parent createAccountFrame = FXMLLoader.load(getClass().getResource("CreateAccountFrame.fxml"));
        Scene createAccountScene = new Scene(createAccountFrame);
        Stage getCreateAccountFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAccountFrame.setScene(createAccountScene);
        getCreateAccountFrame.show();
        
    }
    
    @FXML
    private void handleAssignEmployeeTask(ActionEvent event) throws IOException {
        Parent assignEmployeeTaskFrame = FXMLLoader.load(getClass().getResource("AssignEmployeeTaskFrame.fxml"));
        Scene assignEmployeeTaskScene = new Scene(assignEmployeeTaskFrame);
        Stage getassignEmployeeTaskFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getassignEmployeeTaskFrame.setScene(assignEmployeeTaskScene);
        getassignEmployeeTaskFrame.show();
        
    }
    
    @FXML
    private void handleRemoveEmployee(ActionEvent event) throws IOException {
        Parent removeEmployeeFrame = FXMLLoader.load(getClass().getResource("RemoveEmployeeFrame.fxml"));
        Scene removeEmployeeScene = new Scene(removeEmployeeFrame);
        Stage getRemoveEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getRemoveEmployeeFrame.setScene(removeEmployeeScene);
        getRemoveEmployeeFrame.show();
        
    }
    
    @FXML
    private void handleCreateAnnouncement(ActionEvent event) throws IOException {
        Parent createAnnouncementFrame = FXMLLoader.load(getClass().getResource("CreateAnnouncementFrame.fxml"));
        Scene createAnnouncementScene = new Scene(createAnnouncementFrame);
        Stage getCreateAnnouncementFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAnnouncementFrame.setScene(createAnnouncementScene);
        getCreateAnnouncementFrame.show();
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        title.setText("Welcome, " + user);
        notifyManager.getChildren().addAll(EmployeeFrameController.send);
        percentComplete.setText(Integer.toString(percentage) + "%");
        
        // getting date to display on the manager dash
        Date todaysDate = new Date();
        DateFormat dateForDash = new SimpleDateFormat("E MMM dd yyyy");
        String dashDate = dateForDash.format(todaysDate);
        onDate.setText(dashDate);
        
        
        todaysTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        nextTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        // for updating the imports tab
        File importsData = new File("Imports.txt");
        
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
               
                panes.add(new TitledPane(lineFind, new Label(readData.readLine()
                        + System.lineSeparator() + readData.readLine() +
                         System.lineSeparator() + readData.readLine())));
               
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt");
        
        try{
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX;
            
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            while((lineX = readExportsData.readLine()) != null) {
               
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine() + 
                        System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e);
        }
        
        // for updating the tasks section
        File tasksData = new File("Tasks.txt");
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate localDate = LocalDate.now(); // today's date
        LocalDate weekToday = localDate.plusWeeks(1); // next week
       
        // turning date into string
        String date = d.format(localDate);
        
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        
        try{
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
                
            String liner;
            LocalDate dateInFile;
            
            while((liner = readTasksData.readLine()) != null) {
                // first line is date
                // second line is user
                // last line is task
                try {
                    dateInFile = LocalDate.parse(liner, d);
                    
                    if(liner.isEmpty()) {
                        continue;
                    }
                    if(date.equals(liner)) {
                        liner = readTasksData.readLine();
                        if(liner.equals(user) || liner.equals("All Managers")) {
                            liner = readTasksData.readLine();
                            tasks.add(new CheckBox(liner));
                        }
                    }
                    else {
                        if(localDate.compareTo(dateInFile) <= 0 && dateInFile.compareTo(weekToday) < 0){
                            liner = readTasksData.readLine();
                            if(liner.equals(user) || liner.equals("All Managers")) {
                                liner = readTasksData.readLine();
                                upcomingTasks.add(new CheckBox(liner));
                            }
                        }
                    }
                
                } catch (Exception e) {
                    // Throw invalid date message
                }
            }
            
            today.getChildren().addAll(tasks);
            upcoming.getChildren().addAll(upcomingTasks);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        // TODO updating the inventory chart yikes
        // will need access to the variables in LoadInvetoryDataController
        // instance vars: inventory (BarChart), inventoryLastUpdate (Label), pb (ProgressBar)
       
    }    
    
}
