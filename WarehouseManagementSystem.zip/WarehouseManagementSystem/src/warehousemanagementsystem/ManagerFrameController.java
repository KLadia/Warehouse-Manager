/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * FXML Controller class
 *
 * @author chelseaatkins
 */
public class ManagerFrameController implements Initializable {
    
    String user = LoginFrameController.enteredUsername;
    int percentage = (int) Math.round((EmployeeFrameController.taskComplete / 
            EmployeeFrameController.taskCount) * 100);
    
    static String reassignTaskText;
    static String reassignEmployee;
    static String reassignDate;
    
    @FXML
    private Label title;
    
    @FXML
    private Label percentComplete;
    
    @FXML
    private Label onDate;
    
    @FXML
    private Accordion imports;
    
    @FXML
    private Accordion exports;
    
    @FXML
    private VBox notifyManager;
    
    @FXML
    private Label notifications;
    
    @FXML
    private VBox today;
    
    @FXML
    private Label taskText;
    
    @FXML
    private VBox upcoming;
    
    @FXML
    private ScrollPane todaysTasks;
    
    @FXML
    private ScrollPane nextTasks;
    
    @FXML
    private BarChart inventory;
    
    @FXML
    private CategoryAxis category;
    
    @FXML
    private NumberAxis numbers;
    
    @FXML
    private Label inventoryLastUpdate;
    
    @FXML
    private ProgressBar pb;
    
    @FXML
    private VBox forChart;
    
    
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        logoutFrameScene.getStylesheets().add(css);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @FXML
    private void handleLoadInventory(ActionEvent event) throws IOException {
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LoadInvetoryData.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
        
        // refresh manager frame when popup is closed to show new bar chart components
        dialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
                    Scene managerFrameScene = new Scene(managerFrame);
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    managerFrameScene.getStylesheets().add(css);
                    Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    getManagerFrame.setScene(managerFrameScene);
                    getManagerFrame.show();
                } catch (IOException e) {
                    // catch message
                }
            }
        });
    }
    
    @FXML
    private void handleCreateAccount(ActionEvent event) throws IOException {
        Parent createAccountFrame = FXMLLoader.load(getClass().getResource("CreateAccountFrame.fxml"));
        Scene createAccountScene = new Scene(createAccountFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createAccountScene.getStylesheets().add(css);
        Stage getCreateAccountFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAccountFrame.setScene(createAccountScene);
        getCreateAccountFrame.show();
        
    }
    
    @FXML
    private void handleAssignEmployeeTask(ActionEvent event) throws IOException {
        Parent assignEmployeeTaskFrame = FXMLLoader.load(getClass().getResource("AssignEmployeeTaskFrame.fxml"));
        Scene assignEmployeeTaskScene = new Scene(assignEmployeeTaskFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        assignEmployeeTaskScene.getStylesheets().add(css);
        Stage getassignEmployeeTaskFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getassignEmployeeTaskFrame.setScene(assignEmployeeTaskScene);
        getassignEmployeeTaskFrame.show();
        
    }
    
    @FXML
    private void handleRemoveEmployee(ActionEvent event) throws IOException {
        Parent removeEmployeeFrame = FXMLLoader.load(getClass().getResource("RemoveEmployeeFrame.fxml"));
        Scene removeEmployeeScene = new Scene(removeEmployeeFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        removeEmployeeScene.getStylesheets().add(css);
        Stage getRemoveEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getRemoveEmployeeFrame.setScene(removeEmployeeScene);
        getRemoveEmployeeFrame.show();
        
    }
    
    @FXML
    private void handleCreateAnnouncement(ActionEvent event) throws IOException {
        Parent createAnnouncementFrame = FXMLLoader.load(getClass().getResource("CreateAnnouncementFrame.fxml"));
        Scene createAnnouncementScene = new Scene(createAnnouncementFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createAnnouncementScene.getStylesheets().add(css);
        Stage getCreateAnnouncementFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAnnouncementFrame.setScene(createAnnouncementScene);
        getCreateAnnouncementFrame.show();
    }
    
    @FXML
    private void handleViewAllNotifications(ActionEvent event) throws IOException {
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ViewAllNotifications.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        title.setText("Welcome, " + user);        
        percentComplete.setText(Integer.toString(percentage) + "%");
        inventoryLastUpdate.setText(" ");
        // getting date to display on the manager dash
        Date todaysDate = new Date();
        DateFormat dateForDash = new SimpleDateFormat("E MMM dd yyyy");
        String dashDate = dateForDash.format(todaysDate);
        onDate.setText(dashDate);
        
        
        todaysTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        nextTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        // updates notifications on manager dashboard
        File notificationsData = new File("Notifications.txt");
        
        try{
            FileReader readNotifications = new FileReader(notificationsData);
            BufferedReader readData = new BufferedReader((readNotifications));
            
            String lineFind; // used for reading through file
            String notify = "";
            
            // temporarily stores and formats all notifications from file
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) { // reading through file
                temp.add(lineFind); // add each line in the file to array list
            }
            // search through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent notification at the top
                notify += (temp.get(i) + System.lineSeparator());
                notifications.setText(notify); // set label text
            }
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        // for updating the imports tab
        File importsData = new File("Imports.txt");
        
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
               
                panes.add(new TitledPane(lineFind, new Label(readData.readLine()
                        + System.lineSeparator() + readData.readLine() +
                         System.lineSeparator() + readData.readLine())));
               
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt");
        
        try{
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX;
            
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            while((lineX = readExportsData.readLine()) != null) {
               
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine() + 
                        System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e);
        }
        
        // for updating the tasks section
        File tasksData = new File("Tasks.txt");
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("M/d/yyyy");
        LocalDate localDate = LocalDate.now(); // today's date
        LocalDate weekToday = localDate.plusWeeks(1); // next week
        LocalDate weeksAgo = localDate.minusWeeks(52); // previous week
       
        // turning date into string
        String date = d.format(localDate);
        
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        List<Label> taskStuff = new ArrayList<Label>();
        try{
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
                
            String liner;
            LocalDate dateInFile;
            
            while((liner = readTasksData.readLine()) != null) {
                try {
                    dateInFile = LocalDate.parse(liner, d);
                    
                    if(date.equals(liner)) {
                        liner = readTasksData.readLine();
                        String whosTask = liner;
                        liner = readTasksData.readLine();
                        taskStuff.add(new Label(whosTask + ": " + liner + System.lineSeparator()));
                        // taskText.setText(whosTask + ": " + liner + System.lineSeparator());  
                    }
                    else {
                        // for overdue tasks (yes it says upcoming, disregard)
                         if(localDate.compareTo(dateInFile) >= 0 && dateInFile.compareTo(weeksAgo) > 0){
                            String who = readTasksData.readLine();
                            liner = readTasksData.readLine();
                            upcomingTasks.add(new CheckBox(liner + " assigned to " + who));
                        }
                    }
                
                } catch (Exception e) {
                    // Throw invalid date message
                }
            }
          
            today.getChildren().addAll(taskStuff);
            upcoming.getChildren().addAll(upcomingTasks); // which is now overdue tasks
            
        } catch(Exception e) {
            System.out.println(e);
        } 
        
        // handler for checking and unchecking tasks
        // array list checked handles events for dynamic list of checkboxes
        EventHandler checked = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for (int i = 0; i < upcomingTasks.size(); i++) {
                    if (event.getSource() == upcomingTasks.get(i)) {
                        
                        // we only want the task deatils before the 'assigned' portion
                        int quit_position = upcomingTasks.get(i).getText().indexOf(" assigned");
                        if (quit_position >= 0) {
                            reassignTaskText = upcomingTasks.get(i).getText().substring(0, quit_position);
                        }
                        else {
                            reassignTaskText = upcomingTasks.get(i).getText();
                        }
                        
                        try {
                            handleReassign(event);
                            
                        } catch (IOException e) {
                            System.out.println(e);
                        }
                    }
                }
            }
        };
        
        for (int i = 0; i < upcomingTasks.size(); i++) { // adding action handlers
            upcomingTasks.get(i).setOnAction(checked);
        }
        
        for (int i = 0; i < tasks.size(); i++) { // adding action handlers
            tasks.get(i).setOnAction(checked);
        }
        
       
        // for inventory stacked bar chart
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> sbc = new BarChart<String, Number>(xAxis, yAxis);
        XYChart.Series<String, Number> series1 = new XYChart.Series<String, Number>();
        XYChart.Series<String, Number> series2 = new XYChart.Series<String, Number>();
        
        xAxis.setLabel("Component");
        yAxis.setLabel("Number of Items");
        
        series1.setName("Incomplete Items");
        series2.setName("Inventoried Items");
        
        try{
            FileReader readInventory = new FileReader(new File("Inventory.txt"));
            BufferedReader readInventoryData = new BufferedReader((readInventory));
                
            String line;
            String nextLine;
            
            while((line = readInventoryData.readLine()) != null) {
                nextLine = readInventoryData.readLine();
                series1.getData().add(new XYChart.Data(line, Integer.parseInt(nextLine)));
            }
            
        } catch (Exception e) { 
            System.out.println(e);
        }
        
        try{
            FileReader readInventory = new FileReader(new File("InventoryCompleted.txt"));
            BufferedReader readInventoryData = new BufferedReader((readInventory));
                
            String line;
            String nextLine;
            
            while((line = readInventoryData.readLine()) != null) {
                nextLine = readInventoryData.readLine();
                series2.getData().add(new XYChart.Data(line, Integer.parseInt(nextLine)));
            }
            
        } catch (Exception e) { 
            System.out.println(e);
        }
        
        sbc.getData().addAll(series1, series2);
        
        // throw it in a vbox
        forChart.getChildren().addAll(sbc);
    }
    
    @FXML
    private void handleReassign(ActionEvent event) throws IOException {
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ReassignTaskFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
        
        // refresh the manager dashboard after closing the reassign popup (shows updated tasks)
        dialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
                    Scene managerFrameScene = new Scene(managerFrame);
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    managerFrameScene.getStylesheets().add(css);
                    Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    getManagerFrame.setScene(managerFrameScene);
                    getManagerFrame.show();
                } catch (IOException e) {
                    // catch message
                }
            }
        });
        
    }
    
}
