/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author chelseaatkins
 */
public class ManagerFrameController implements Initializable {
    
    String user = LoginFrameController.enteredUsername;
    
    @FXML
    private Label title;
    
    @FXML
    private Accordion imports;
    
    @FXML
    private Accordion exports;
    
    @FXML
    private VBox notifyManager;

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @FXML
    private void handleCreateAccount(ActionEvent event) throws IOException {
        Parent createAccountFrame = FXMLLoader.load(getClass().getResource("CreateAccountFrame.fxml"));
        Scene createAccountScene = new Scene(createAccountFrame);
        Stage getCreateAccountFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAccountFrame.setScene(createAccountScene);
        getCreateAccountFrame.show();
        
    }
    
    @FXML
    private void handleAssignEmployeeTask(ActionEvent event) throws IOException {
        Parent assignEmployeeTaskFrame = FXMLLoader.load(getClass().getResource("AssignEmployeeTaskFrame.fxml"));
        Scene assignEmployeeTaskScene = new Scene(assignEmployeeTaskFrame);
        Stage getassignEmployeeTaskFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getassignEmployeeTaskFrame.setScene(assignEmployeeTaskScene);
        getassignEmployeeTaskFrame.show();
        
    }
    
    @FXML
    private void handleRemoveEmployee(ActionEvent event) throws IOException {
        Parent removeEmployeeFrame = FXMLLoader.load(getClass().getResource("RemoveEmployeeFrame.fxml"));
        Scene removeEmployeeScene = new Scene(removeEmployeeFrame);
        Stage getRemoveEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getRemoveEmployeeFrame.setScene(removeEmployeeScene);
        getRemoveEmployeeFrame.show();
        
    }
    
    @FXML
    private void handleCreateAnnouncement(ActionEvent event) throws IOException {
        Parent createAnnouncementFrame = FXMLLoader.load(getClass().getResource("CreateAnnouncementFrame.fxml"));
        Scene createAnnouncementScene = new Scene(createAnnouncementFrame);
        Stage getCreateAnnouncementFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAnnouncementFrame.setScene(createAnnouncementScene);
        getCreateAnnouncementFrame.show();
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        title.setText("Welcome, " + user);
        notifyManager.getChildren().addAll(EmployeeFrameController.send);
        
        // for updating the imports tab
        File importsData = new File("Imports.txt");
        
        try{
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
                
            String lineFind;
            
            List<TitledPane> panes = new ArrayList<TitledPane>();
            while((lineFind = readData.readLine()) != null) {
               
                panes.add(new TitledPane(lineFind, new Label(readData.readLine()
                        + System.lineSeparator() + readData.readLine() +
                         System.lineSeparator() + readData.readLine())));
               
            }
            
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt");
        
        try{
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
                
            String lineX;
            
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            while((lineX = readExportsData.readLine()) != null) {
               
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine() + 
                        System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
    }    
    
}
