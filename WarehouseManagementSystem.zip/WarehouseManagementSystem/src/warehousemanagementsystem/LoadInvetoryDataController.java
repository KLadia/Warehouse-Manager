package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class LoadInvetoryDataController implements Initializable {
    
    String newComponent;
    String newItems;
    
    String completedComponent;
    String completedItems;
    
    static String date;
    
    @FXML
    private Label notificationTop;
    
    @FXML
    private Label notificationBottom;
    
    @FXML
    private TextField compNew;
    
    @FXML
    private TextField itemsnew;
    
    @FXML
    private ComboBox compComplete;
    
    @FXML
    private TextField itemsComplete;
    
    @FXML
    private void handleNew(ActionEvent event) throws IOException {
        newComponent = compNew.getText();
        newItems = itemsnew.getText();
        
        // validating user input
        if(!newComponent.startsWith(" ") && !newItems.startsWith(" ") && 
                !newComponent.equals("") && !newItems.equals("")) {
            compNew.setText(null);
            itemsnew.setText(null);
            
            try {
                FileWriter data = new FileWriter(new File("Inventory.txt"), true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(newComponent);
                storeData.newLine();
                storeData.append(newItems);
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            Calendar cal = Calendar.getInstance();
            date = cal.getTime().toString();
            
        }
        else {
            notificationTop.setText("Something went wrong");
            notificationTop.setTextFill(Color.RED);
        }
    }
    
    @FXML
    private void handleComplete(ActionEvent event) throws IOException {
        String completedComp = compComplete.getValue().toString();
        String completedItem = itemsComplete.getText();
        
        // validating user input
        if(!completedItem.startsWith(" ") && !(compComplete.getSelectionModel().isEmpty()) && 
                !completedItem.equals("")) {
            itemsComplete.setText(null);
            try {
                FileWriter data = new FileWriter(new File("InventoryCompleted.txt"), true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(completedComp);
                storeData.newLine();
                storeData.append(completedItem);
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            notificationBottom.setText("Success");
            notificationBottom.setTextFill(Color.WHITE);
        }
        else {
            notificationBottom.setText("Something went wrong");
            notificationBottom.setTextFill(Color.RED);
        }
    }
    
    @FXML
    private void handleClear(ActionEvent event) throws IOException {
        // create popup (are you sure you want to clear inventory data?)
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ApproveInventoryRemoval.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // populate the combo box of components that have already been added to file        
        try{
            FileReader readInventory = new FileReader(new File("Inventory.txt"));
            BufferedReader readData = new BufferedReader((readInventory));
            
            String line; // used for reading through file
            
            // temporarily stores all components from file
            List<String> temp = new ArrayList<String>();
            
            while((line = readData.readLine()) != null) { // reading through file
                temp.add(new String(line)); // add each line in the file to array list
                line = readData.readLine(); // skip the line with number of items
            }
            
            compComplete.getItems().addAll(temp);
            
        } catch(Exception e) {
                System.out.println(e);
        } 
    }    
}
