package warehousemanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class LoadInvetoryDataController implements Initializable {
    
    static String newComponent;
    static String newItems;
    
    static String completedComponent;
    static String completedItems;
    
    @FXML
    private Label notificationTop;
    
    @FXML
    private Label notificationBottom;
    
    @FXML
    private TextField compNew;
    
    @FXML
    private TextField itemsnew;
    
    @FXML
    private TextField compComplete;
    
    @FXML
    private TextField itemsComplete;
    
    @FXML
    private void handleNew(ActionEvent event) throws IOException {
        
        newComponent = compNew.getText();
        newItems = itemsnew.getText();
        compNew.setText(null);
        itemsnew.setText(null);
        notificationTop.setText("Component and item successfully added");
        
    }
    
    @FXML
    private void handleComplete(ActionEvent event) throws IOException {
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
