package warehousemanagementsystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class OrderProductFrameController implements Initializable {
    String user = LoginFrameController.enteredUsernameEmp;
    private String storedUPC;
    private String storedDescription;
    private String storedDate;
    
    @FXML
    private Text box;
    
    @FXML
    private Text boxCheck;
    
    @FXML
    private TextField upc;
    
    @FXML
    private TextArea description;
    
    @FXML
    private DatePicker date;
    
    @FXML
    private Label confirm;
    
    @FXML
    private Label detailsUPC;
    
    @FXML
    private Label detailsDescription;
    
    @FXML
    private Label detailsDate;
    
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent employeeFrame = FXMLLoader.load(getClass().getResource("EmployeeFrame.fxml"));
        Scene employeeFrameScene = new Scene(employeeFrame);
        Stage getEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getEmployeeFrame.setScene(employeeFrameScene);
        getEmployeeFrame.show();
    }
    
    @FXML
    private void handleVerify(ActionEvent event) throws IOException {
        Calendar cal = Calendar.getInstance();
        File storedData = new File("Imports.txt");
        storedUPC = upc.getText();
        storedDescription = description.getText();
        storedDate = date.getEditor().getText();
        
        if(upc == null || date == null || description == null || storedUPC.equals("") ||
           storedDescription.equals("") || storedDate.equals("")) {
            box.setVisible(true);
            boxCheck.setVisible(false);
            confirm.setText("   Something went wrong");
            detailsDate.setText("Please fill out all fields");
            detailsDescription.setText("");
        }
        else if((storedUPC.length()) != 12) { // check UPC size
            box.setVisible(true);
            boxCheck.setVisible(false);
            confirm.setText("   Something went wrong");
            detailsUPC.setText("Incorrect UPC length");
            detailsDescription.setText("");
            detailsDate.setText("");
        }
        else {
            try {
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append("UPC: " + storedUPC);
                storeData.newLine();
                storeData.append("Delivery Date: " + storedDate);
                storeData.newLine();
                storeData.append("Product Description: " + storedDescription);
                storeData.newLine();
                storeData.append("Order Placed By: " + user + " on " + cal.getTime());
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            box.setVisible(false);
            boxCheck.setVisible(true);
            confirm.setText("Order successfully placed!");
            detailsUPC.setText("UPC: " + storedUPC);
            detailsDate.setText("Delivery Date: " + storedDate);
            detailsDescription.setText("Product Description: " + storedDescription);
            
            // reset tht text fields and text areas
            upc.setText(null);
            description.setText(null);
            date.getEditor().setText(null);
        }
        
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        box.setVisible(false);
        boxCheck.setVisible(false);
    }
    
}
