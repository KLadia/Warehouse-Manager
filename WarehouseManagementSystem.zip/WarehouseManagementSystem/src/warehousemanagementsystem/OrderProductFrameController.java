/* 
 * orderproductframecontroller.java
 *
 * This frame allows the employee to order a new product for the warehouse. They can
 * add a product code, item description, and when the estimated delivery date
 * for the item will be. The information is stored to imports.txt and is accessed by
 * both the employee and manager frames to update the import tab on each.
 *
 * @author : andrewaaran (Sep 12 2017)
 *
 * @SQA    : danielafuenzalida (last tested Dec 1 2017)
 * 
 */

package warehousemanagementsystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class OrderProductFrameController implements Initializable {
    
    // get username from login controller to find out who placed the order
    String user = LoginFrameController.enteredUsernameEmp;
    
    // strings for storing information taken from the GUI elements
    private String storedUPC;
    private String storedDescription;
    private String storedDate;
    
    @FXML
    private Text box; // for the red x over cardboard box
    
    @FXML
    private Text boxCheck; // for the green check mark over the cardboard box
    
    @FXML
    private TextField upc; // for the GUI textfield with upc
    
    @FXML
    private TextArea description; // text area that holds product description
    
    @FXML
    private DatePicker date; // to pick the date the product will be delviered
    
    @FXML
    private Label confirm; // error message label to confirm success or fail
    
    @FXML
    private Label detailsUPC; // label for returning entered UPC information
    
    @FXML
    private Label detailsDescription; // label for returning entered details
    
    @FXML
    private Label detailsDate; // label for returning entered date
    
    
    // handler for back to employee hyperlink at the top
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        // create employee frame as new parent scene
        Parent employeeFrame = FXMLLoader.load(getClass().getResource("EmployeeFrame.fxml"));
        Scene employeeFrameScene = new Scene(employeeFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        employeeFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getEmployeeFrame.setScene(employeeFrameScene);
        getEmployeeFrame.show();
    }
    
    // handle when the employee hits the verify button to place new order
    @FXML
    private void handleVerify(ActionEvent event) throws IOException {
        
        // get current date for adding to the file for when order was placed
        Calendar cal = Calendar.getInstance();
        
        // file to append
        File storedData = new File("Imports.txt");
        
        // get information from the GUI elements and store information
        storedUPC = upc.getText();
        storedDescription = description.getText();
        storedDate = date.getEditor().getText();
        
        // valdiating input
        // check if fields are empty
        if(upc == null || date == null || description == null || storedUPC.equals("") ||
           storedDescription.equals("") || storedDate.equals("")) {
            
            box.setVisible(true); // bad input = set red x to visible
            boxCheck.setVisible(false); // hide green check mark
            
            // update error message text
            confirm.setText("   Something went wrong");
            
            // update label with information on the specific error
            detailsDate.setText("Please fill out all fields");
            detailsDescription.setText(""); // not needed
        }
        
        // check UPC length
        else if((storedUPC.length()) != 12) {
            
            box.setVisible(true); // bad input = set red x to visible
            boxCheck.setVisible(false); // hide green check mark
            
            // update error message text
            confirm.setText("   Something went wrong");
            
            // update label with information on the specific error
            detailsUPC.setText("Incorrect UPC length");
            detailsDescription.setText(""); // not needed
            detailsDate.setText(""); // not needed
        }
        
        // if we get here then everything is confirmed and we can append the info
        else {
            
            try {
                // these are the writers used to append the data line by line
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                
                // store each new piece of info on a new line
                // append UPC on a new line
                storeData.append("UPC: " + storedUPC);
                storeData.newLine();
                
                // append delivery date on a new line
                storeData.append("Delivery Date: " + storedDate);
                storeData.newLine();
                
                // append product description on a new line
                storeData.append("Product Description: " + storedDescription);
                storeData.newLine();
                
                // append order place by and time placed on a new line
                storeData.append("Order Placed By: " + user + " on " + cal.getTime());
                storeData.newLine();
                
                storeData.close(); // close writer
                
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            } // end try-catch for appending import data
            
            box.setVisible(false); // good input = red x hidden
            boxCheck.setVisible(true); // make green check mark visible
            
            // set the label confirmation text
            confirm.setText("Order successfully placed!");
            
            // show confirmed UPc details
            detailsUPC.setText("UPC: " + storedUPC);
            
            // show confirmed delivery date details
            detailsDate.setText("Delivery Date: " + storedDate);
            
            // show confirmed product description details
            detailsDescription.setText("Product Description: " + storedDescription);
            
            // reset that text fields and text areas
            upc.setText(null);
            description.setText(null);
            date.getEditor().setText(null);
            
        } // end conditional bock for validating input
        
    }
    
    // execute this method every time the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // initially set red x and green checkmark to not visible
        box.setVisible(false);
        boxCheck.setVisible(false);
    }
    
}
