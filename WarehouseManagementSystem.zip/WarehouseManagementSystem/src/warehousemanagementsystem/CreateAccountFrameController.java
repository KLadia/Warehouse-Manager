/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static warehousemanagementsystem.LoginFrameController.enteredUsernameEmp;

public class CreateAccountFrameController implements Initializable {
    
    @FXML
    private RadioButton chooseEmployee;
    
    @FXML
    private RadioButton chooseManager;
    
    @FXML
    private Label topNote;
    
    @FXML
    private Label bottomNote;
    
    @FXML
    private TextField userNameField;
    
    @FXML
    private TextField passwordField;
    
    @FXML
    private TextField confirmField;
    
    
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    
    // create a new text file for every employee and manager
    // rewrite to csv and store the employees id in the csv file
    // seperate information with commas instead of reading line
    // generate an invoice file saved as a csv detailing product name, price, and total
    
    @FXML
    private void handleCreate(ActionEvent event) throws IOException {
        
        if(userNameField.getText().startsWith(" ") || passwordField.getText().startsWith(" ")
                || userNameField.getText().equals("") || passwordField.getText().equals("")) {
            bottomNote.setText("Please fill in all fields");
        }
        else {
           bottomNote.setText(" ");
        }
        
        if (!(chooseEmployee.isSelected()) && !(chooseManager.isSelected())) {
             topNote.setText("Please choose an account type");
        }
        if (chooseEmployee.isSelected() && chooseManager.isSelected()) {
                topNote.setText("Please only choose one account type");
        }
        // creating an employee account
        else if(chooseEmployee.isSelected() && !(chooseManager.isSelected())) {
            topNote.setText(" ");
            bottomNote.setText(" ");
            
            // start the checking... I literally have no idea how this works
            // @Crick.E.T. I figured this out through sheer luck and trial and error
            String storedUsername = userNameField.getText();
            String storedPassword = passwordField.getText();
            
            File storedDataEmployee = new File("StoredDataEmployee.txt");
            File storedDataManager = new File("StoredDataManager.txt");
            try{
                FileReader readEmpData = new FileReader(storedDataEmployee);
                BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
                // for manager comparison (checking username exists)
                FileReader readManData = new FileReader(storedDataManager);
                BufferedReader readManagerData = new BufferedReader((readManData));
                
                String line;
                String otherLine;
                boolean userExists = false;
                while((line = readEmployeeData.readLine()) != null) {
                    while((otherLine = readManagerData.readLine()) != null) {
                        if(storedUsername.equals(line) || storedUsername.equals(otherLine)) {
                            bottomNote.setText("Username already used");
                            userExists = true;
                            break;
                        }
                    }
                }
                if(!userExists) {
                    FileWriter data = new FileWriter(storedDataEmployee, true);
                    BufferedWriter storeData = new BufferedWriter(data);
                    storeData.append(storedUsername);
                    storeData.newLine();
                    storeData.append(storedPassword);
                    storeData.newLine();
                    storeData.close();
                }
            } catch(Exception e) {
                System.out.println(e);
            }
        }
        
        // creating a manager account
        else if(chooseManager.isSelected() && !(chooseEmployee.isSelected())) {
            topNote.setText(" ");
            bottomNote.setText(" ");
            
            // start the checking...
            String storedUsername = userNameField.getText();
            String storedPassword = passwordField.getText();
            
            File storedDataEmployee = new File("StoredDataEmployee.txt");
            File storedDataManager = new File("StoredDataManager.txt");
            try{
                FileReader readManData = new FileReader(storedDataManager);
                BufferedReader readManagerData = new BufferedReader((readManData));
                
                // for employee comparison (checking username exists)
                FileReader readEmpData = new FileReader(storedDataEmployee);
                BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
                String line;
                String otherLine;
                boolean userExists = false;
                while((line = readManagerData.readLine()) != null) {
                    while((otherLine = readEmployeeData.readLine()) != null) {
                        if(storedUsername.equals(line) || storedUsername.equals(otherLine)) {
                            bottomNote.setText("Username already used");
                            userExists = true;
                            break;
                        }
                    }
                }
                if(!userExists) {
                    FileWriter data = new FileWriter(storedDataManager, true);
                    BufferedWriter storeData = new BufferedWriter(data);
                    storeData.append(storedUsername);
                    storeData.newLine();
                    storeData.append(storedPassword);
                    storeData.newLine();
                    storeData.close();
                }
            } catch(Exception e) {
                System.out.println(e);
            }
        }
        
        /*if ((userNameField.getText().equals("")) || (passwordField.getText().equals(""))
                || (confirmField.getText().equals("")) || 
                (!((passwordField.getText()).equals(confirmField.getText())))) {
            emptyFields.setText("Please fill in all fields");
            
            // neither account options are selected
            if(!(chooseEmployee.isSelected()) && !(chooseManager.isSelected())) {
                chooseManagerOrEmployee.setText("Please choose an account type");
            }
            // one of the account options are selected (label hidden)
            if(chooseEmployee.isSelected() || chooseManager.isSelected()) {
                if((chooseEmployee.isSelected()) && (chooseManager.isSelected())) {
                    chooseManagerOrEmployee.setText("Only choose one account type");
                }
                else {
                    chooseManagerOrEmployee.setText(" ");
                }
            }
        
            if(!((passwordField.getText()).equals(confirmField.getText()))) {
                emptyFields.setText(" ");
                matchingPassword.setText("Passwords do not match");
            } else {
                matchingPassword.setText(" ");
            }
        }
        else { // go to login if all fields are filled and store info
            if(chooseEmployee.isSelected()) {
                storedUsername = userNameField.getText();
                storedPassword = passwordField.getText();
            
                File storedData = new File("StoredDataEmployee.txt");
            
                try {
                    FileWriter data = new FileWriter(storedData, true);
                    BufferedWriter storeData = new BufferedWriter(data);
                    storeData.append(storedUsername);
                    storeData.newLine();
                    storeData.append(storedPassword);
                    storeData.newLine();
                    storeData.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(chooseManager.isSelected()) {
                storedUsername = userNameField.getText();
                storedPassword = passwordField.getText();
            
                File storedData = new File("StoredDataManager.txt");
            
                try {
                    FileWriter data = new FileWriter(storedData, true);
                    BufferedWriter storeData = new BufferedWriter(data);
                    storeData.append(storedUsername);
                    storeData.newLine();
                    storeData.append(storedPassword);
                    storeData.newLine();
                    storeData.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Parent loginFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
            Scene loginFrameScene = new Scene(loginFrame);
            Stage getLoginFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
            getLoginFrame.setScene(loginFrameScene);
            getLoginFrame.show();
        }*/
    }
    
    // initialize controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
