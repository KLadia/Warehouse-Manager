/* 
 * loginframecontroller.java
 *
 * This is the login frame. It features two tabs, an employee login and a
 * manager login. It reads from manager and employee data files to validate
 * usernames and passwords and allows the user access to their respective
 * dashboards. This frame is loaded upon start or accessed after successfully
 * creating an account (done by manager).
 *
 * @author : chelseaatkins (Sep 1 2017)
 *
 * @SQA    : kristinladia (last tested Sep 12 2017)
 *
 * @update : chelseaatkins (Sep 9 2017) - cleaned up validation
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginFrameController implements Initializable {
    
    // there variables are used to entered user name
    // they're shared to different frames to get the current user
    static String enteredUsername = "";
    static String enteredUsernameEmp;
            
    @FXML
    private Label notification; // notification label for manager tab
    
    @FXML
    private Label notificationEmp; // notificaiton label for employee tab
    
    @FXML
    private TextField userNameField; // username field for manager
    
    @FXML
    private TextField passwordField; // password field for manager
    
    @FXML
    private Label emptyFieldsEmp; // notification for empty fields
    
    @FXML
    public TextField userNameFieldEmp; // employee username field
    
    @FXML
    private TextField passwordFieldEmp; // employee password field
    
    @FXML
    private Label incorrectInfo; // notification for incorrect username or password
    
    // handle the login button on the employee tab
    @FXML
    private void handleEmployeeLogin(ActionEvent event) throws IOException {
        
        // validating input
        // bad input = empty fields
        if((userNameFieldEmp.getText().equals("")) || (passwordFieldEmp.getText().equals(""))) {
            emptyFieldsEmp.setText("Please fill in all fields"); // update message
        }
        
        // no empty fields, proceed to check credentials
        else {
            // reading from the employee data
            File storedDataEmployee = new File("StoredDataEmployee.txt");
            
            try{
                // file readers used for accessing the txt file
                FileReader readEmpData = new FileReader(storedDataEmployee);
                BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
                // vairables used for reading throguh lines in the file
                String lineFind;
                String nextLineFind;
                
                // information taken from GUI elements
                enteredUsernameEmp = userNameFieldEmp.getText();
                String enteredPasswordEmp = passwordFieldEmp.getText();
                
                // read through each line in the file until no lines remain
                while((lineFind = readEmployeeData.readLine()) != null) {
                    
                    // lineFind is implicitly read in while loop and stored username
                    // nextLineFind is the passowrd
                    nextLineFind = readEmployeeData.readLine();
                    
                    // check if the username and passwords match data in file
                    if(!(enteredUsernameEmp.equals(lineFind)) || !(enteredPasswordEmp.equals(nextLineFind))) {
                        // set error message if credentials do not match
                        emptyFieldsEmp.setText(" ");
                        notificationEmp.setText("Incorrect username or password");
                    }
                    
                    // credentials are good and we can load employee frame
                    else {
                        // for showing the employee frame as the new parent scene
                        Parent employeeFrame = FXMLLoader.load(getClass().getResource("EmployeeFrame.fxml"));
                        Scene employeeFrameScene = new Scene(employeeFrame);
                        // @daniela : add css style sheet
                        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                        employeeFrameScene.getStylesheets().add(css);
                        // end css resource
                        Stage getEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        getEmployeeFrame.setScene(employeeFrameScene);
                        getEmployeeFrame.show();
                    }
                } // end reading through the employee data file
            } catch(Exception e) {
                System.out.println(e);
            } // end try-catch for reading through the employee data file
        } // end input validation conditional block
    } // end handleEmployeeLogin method
    
    // handle the login button for the manager tab
    @FXML
    private void handleManagerLogin(ActionEvent event) throws IOException {
        
        // validate input
        if((userNameField.getText().equals("")) || (passwordField.getText().equals(""))) {
            
            // set error message for empty fields
            notification.setText("Please fill in all fields");
            incorrectInfo.setText(" ");
        }
        
        // input if good, now time to check credentials
        else {
            // file to read from
            File storedDataManager = new File("StoredDataManager.txt");
            
            try{
                // file reader for reading manager data
                FileReader readData = new FileReader(storedDataManager);
                BufferedReader readManagerData = new BufferedReader((readData));
                
                // variables used for reading through file
                String line;
                String nextLine;
                
                // getting information from GUI elements
                enteredUsername = userNameField.getText();
                String enteredPassword = passwordField.getText();
                
                // read through each line in file until none are left
                while((line = readManagerData.readLine()) != null) {
                    
                    // line implicitly read in while conditional, stores username
                    // nextLine stores password
                    nextLine = readManagerData.readLine();
                    
                    // check if the username and password match
                    if(!(enteredUsername.equals(line)) || !(enteredPassword.equals(nextLine))) {
                        
                        // display error message if they are not correct
                        notification.setText(" ");
                        incorrectInfo.setText("Incorrect username or password");
                    }
                    // credentials are good, load manager frame
                    else {
                        // for showing the manager frame as the new parent scene
                        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
                        Scene managerFrameScene = new Scene(managerFrame);
                        // @daniela : add css style sheet
                        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                        managerFrameScene.getStylesheets().add(css);
                        // end css resource
                        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        getManagerFrame.setScene(managerFrameScene);
                        getManagerFrame.show();
                    }
                } // end while loop for reading manager data
            } catch(Exception e) {
                System.out.println(e);
            } // end try-catch for reading from manager data
        } // end conditional block for input validation
    } // end handleManagerLogin method
    
    // initialize controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // nothing needs to load upon initialization
    }    
    
}
