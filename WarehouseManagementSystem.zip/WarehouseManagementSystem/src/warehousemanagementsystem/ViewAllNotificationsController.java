package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ViewAllNotificationsController implements Initializable {

    @FXML
    private Label notifications;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        // this pane will scroll
        File AnnouncementsData = new File("Notifications.txt");
        
        try{
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            String lineFind;
            String storeAnnouncements = "";
            
            List<String> temp = new ArrayList<String>();
            
            while((lineFind = readData.readLine()) != null) {
                temp.add(lineFind);
                
            }
            for(int i = temp.size() - 1; i >= 0; i--) {
                storeAnnouncements += (temp.get(i) + System.lineSeparator());
                notifications.setText(storeAnnouncements);
            }
        } catch(Exception e) {
                System.out.println(e);
        } 
    }
}
