/* 
 * viewallnotifications.java
 *
 * This is the class that controls the popup for viewing all the notifications.
 * It features a scrollbar to view all the notifications.
 *
 * @author : chelseaatkins (Oct 21 2017)
 *
 * @SQA    : kristinladia (last tested on Oct 22) 
 * 
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ViewAllNotificationsController implements Initializable {

    @FXML
    private Label notifications; // for displaying notification text
    
    // execute this method everytime the window refreshes
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        // this is the file to read from
        File AnnouncementsData = new File("Notifications.txt");
        
        try{
            // create readers to loop through each line in file
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            // variable for reading each line in the file
            String lineFind;
            
            // variable string to concatenate with later
            String storeAnnouncements = "";
            
            // temporarily store notification info in arraylist
            List<String> temp = new ArrayList<String>();
            
            // read each line in the file until null
            while((lineFind = readData.readLine()) != null) {
                // add each line to the temporary arrayList
                temp.add(lineFind);
            }
            
            // loop through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent notifications at the top
                storeAnnouncements += (temp.get(i) + System.lineSeparator());
                // set notifications label text to display text
                notifications.setText(storeAnnouncements);
            }
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } // end try-catch for reading through notifications.txt
    } // end initializable method
}
