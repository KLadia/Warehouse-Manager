package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class CreateAnnouncementFrameController implements Initializable {
    
    @FXML
    private Label notification;
    
    @FXML
    private TextArea tweet;
    
    @FXML
    private ComboBox directedAt;
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    @FXML
    private void handlePost(ActionEvent event) throws IOException {
        Calendar cal = Calendar.getInstance();

        if(tweet.getText().length() > 150) {
            notification.setText("Your announcement must be under 150 characters");
        }
        else if(tweet.getText().equals("")) {
            notification.setText("Please fill in all fields");
        }
        else {
           
            notification.setText("Your announcement has been created");
            
            File announcementData = new File("Announcements.txt");
            try {
                FileWriter data = new FileWriter(announcementData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append("@" + directedAt.getValue().toString() + ": ");
                storeData.append(tweet.getText());
                storeData.append(" Posted: " + cal.getTime());
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            tweet.setText("");
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind;
        try {
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
            List<String> employees = new ArrayList<String>();
            while((lineFind = readEmployeeData.readLine()) != null) {
                    
                employees.add(new String(lineFind));
                lineFind = readEmployeeData.readLine();
                  
            }
           
            directedAt.getItems().addAll(employees);
            directedAt.getItems().addAll("Staff"); 
            
        } catch(Exception e) {
            System.out.println(e);
        }
    }    
    
}
