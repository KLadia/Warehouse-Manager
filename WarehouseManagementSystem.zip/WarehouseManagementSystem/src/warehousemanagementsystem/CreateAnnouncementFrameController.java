package warehousemanagementsystem;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CreateAnnouncementFrameController implements Initializable {
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
