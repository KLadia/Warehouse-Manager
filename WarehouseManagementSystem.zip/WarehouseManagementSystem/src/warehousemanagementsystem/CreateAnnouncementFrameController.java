/* 
 * createannouncementframecontroller.java
 *
 * This allows the manager to create announcements to employees. Managers can choose
 * who they want the announcement to be directed at and type a message up to 150
 * characters. This behaves like twitter in that all staff members can view messages.
 * Information is stored in the announcements.txt file to be accessed by the employee
 * frame controller.
 *
 * @author : andrewaaran (Sep 13 2017)
 *
 * @SQA    : danielafuenzalida (tested Sep 15 2017) - combobox duplicates employee
 *           names on initizalization, continues to duplicate upon refresh
 *         : kristinladia (last tested Sep 22 2017)
 *
 * @update : chelseaatkins (Sep 15 2017) - fixed combo box duplication
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class CreateAnnouncementFrameController implements Initializable {
    
    @FXML
    private Label notification; // success or error message
    
    @FXML
    private TextArea tweet; // text area to write out the announcement
    
    @FXML
    private ComboBox directedAt; // combo box to see who the announcement should go to
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    // handler for when the user hits the post announcement button
    @FXML
    private void handlePost(ActionEvent event) throws IOException {
        
        // get the local time to add to post
        Calendar cal = Calendar.getInstance();
        
        // @chelsea : validate input
        if(tweet.getText().length() > 150) { // "tweet" too long = bad
            // update label
            notification.setText("Your announcement must be under 150 characters");
        }
        else if(tweet.getText().equals("")) { // blank "tweet" = bad
            // update label
            notification.setText("Please fill in all fields");
        } // end input validation
        else {
            // update label text with success message
            notification.setText("Your announcement has been created");
            notification.setTextFill(Color.web("#ffffff")); // set label text to white
            
            // file to write information to
            // all anouncement details will be written on one line
            File announcementData = new File("Announcements.txt");
            try {
                // file writer and buffered writer elements
                FileWriter data = new FileWriter(announcementData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                
                // add an @ symbol before the user to be directed at when writing to file
                storeData.append("@" + directedAt.getValue().toString() + ": ");
                storeData.append(tweet.getText()); // add tweet text after semicolon
                // append the time posted
                storeData.append(" Posted: " + cal.getTime()); // get the calender time
                storeData.newLine(); // get new line
                storeData.close(); // close file writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            }
            // reset the text field
            tweet.setText("");
        }
    } // end handlePost method
    
    // load this method everytime the page is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // we need to read from employee data to update combo box
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind; // var used for reading through file
        try {
            // file and reader to get data from
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
            
            // @chelsea : changed this to a hashset to stop duplicates
            Set<String> employees = new HashSet<String>(); // store employee variables
            while((lineFind = readEmployeeData.readLine()) != null) {
                // add each new line to the employee set
                employees.add(new String(lineFind));
                lineFind = readEmployeeData.readLine(); // skip next line (passwords)
                  
            } // end reading from employee file
           
            // add employee usernames to combobox with an allstaff option at the bottom
            directedAt.getItems().addAll(employees);
            directedAt.getItems().addAll("All Staff");
            
        } catch(Exception e) {
            System.out.println(e); // no further handler necessary
        }
    } // end initializable method    
}
