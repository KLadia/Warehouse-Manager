package warehousemanagementsystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateAnnouncementFrameController implements Initializable {
    
    @FXML
    private Label notification;
    
    @FXML
    private TextArea tweet;
    
    @FXML
    private TextField directedAt;
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    @FXML
    private void handlePost(ActionEvent event) throws IOException {
        Calendar cal = Calendar.getInstance();

        if(!(directedAt.getText().startsWith("@"))) {
            notification.setText("Please include who this announcement is directed at with the @ symbol");
        }
        else if(tweet.getText().length() > 150) {
            notification.setText("Your announcement must be under 150 characters");
        }
        else if(tweet.getText().equals("") ||directedAt.getText().equals("")) {
            notification.setText("Please fill in all fields");
        }
        else {
            notification.setText("Your announcement has been created");
            
            File announcementData = new File("Announcements.txt");
            try {
                FileWriter data = new FileWriter(announcementData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(directedAt.getText() + ": ");
                storeData.append(tweet.getText());
                storeData.append(" Posted: " + cal.getTime());
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            directedAt.setText("");
            tweet.setText("");
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
