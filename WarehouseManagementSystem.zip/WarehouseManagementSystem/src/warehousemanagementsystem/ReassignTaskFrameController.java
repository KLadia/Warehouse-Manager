/* 
 * reassigntaskframecontroller.java
 *
 * This frame is accessed from the manager dashboard. When a manager selects an
 * overdue task, this frame pops up and automatically populates the associated text
 * box with the task details. The manager can then select a new date and employee
 * to complete the task. The old task is then removed from the file and then the new 
 * task is then appended.
 *
 * @author : andrewaaran (Sep 20 2017)
 *
 * @SQA    : danielafuenzalida (last tested on Nov 30 2017)
 * 
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;


public class ReassignTaskFrameController implements Initializable {
    
    // set of employees (no duplicates allowed)
    static Set<String> employees = new HashSet<String>();
    
    @FXML
    private Label reassignedOrNo; // for success or fail message
    
    @FXML
    private TextField task; // textfield for task details will automatically populate
    
    @FXML
    private ComboBox selectEmployee; // for selecting an employee to assign new task to
    
    @FXML
    private DatePicker date; // option for selecting a date to assign task on
    
    @FXML
    private Button reassign; // button to reassign task
    
    // handler for when the reassign button is clicked
    @FXML
    private void handleReassign(ActionEvent event) throws IOException {
        
        // validating input
        if(task.getText().startsWith(" ") || date.getEditor().getText().equals("") ||
                task.getText().equals("") || date.getEditor().getText().startsWith(" ") ||
                selectEmployee.getSelectionModel().isEmpty()) {
            
            // set the label text with error message
            reassignedOrNo.setText("Something went wrong");
            reassignedOrNo.setTextFill(Color.RED); // change color of label to red
        }
        
        // this removes tasks
        else {
        
            // file to read from
            File inputFile = new File("Tasks.txt");
        
            // file to rename the input to and temporarily store information to
            File tempFile = new File("temp.txt");
        
            // reader and writers for looping through the file with
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
        
            // find initial task to remove based on task from manager frame selection
            String initialTask = ManagerFrameController.reassignTaskText;
            String firstLine; // date
        
            // loop through each line in the file until null
            while((firstLine = reader.readLine()) != null) {
            
                // first line is implicity  read in while coniditonal
                // second and third line read by next line
                String secondLine = reader.readLine();
                String thirdLine = reader.readLine();
            
                // trim newline when comparing with initial task
                String trimmedLine = thirdLine.trim();
            
                // check if the trimmedLine is the same as the intialTask
                // continue loop if true
                if(trimmedLine.equals(initialTask)) continue;
            
                // update text file
                writer.write(firstLine + System.getProperty("line.separator") + 
                    secondLine + System.getProperty("line.separator") + thirdLine + 
                    System.getProperty("line.separator"));
            }
            writer.close(); // close writer
            reader.close(); // close reader
        
            // rename temporary file to original file to remove it
            boolean successful = tempFile.renameTo(inputFile);
            // end task removal
        
            // adding the reassigned task
            File taskData = new File("Tasks.txt"); // file to append
        
            try {
                // files to write to
                FileWriter data = new FileWriter(taskData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                // add date to new line
                storeData.append(date.getEditor().getText());
                storeData.newLine();
                // add employee user to new line
                storeData.append(selectEmployee.getValue().toString());
                storeData.newLine();
                // add task informationt o new line
                storeData.append(task.getText());
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            } // end try-catch for appending tasks.txt
            
            // update label task with success message
            reassignedOrNo.setText("Task successfully reassigned");
        
        } // end conditional block
        
    }
    
    // execute this method everytime the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // populate textfield with selected text information details
        task.setText(ManagerFrameController.reassignTaskText);
        
        // file to redd from to populate combo box
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        
        // variable to read through all lines in the file
        String lineFind;
        
        try {
            // create readers for looping through file
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
              
            // loop through each line in the file until null
            while((lineFind = readEmployeeData.readLine()) != null) {
                
                // add the new line to the employee set
                employees.add(new String(lineFind));
                // ignore the next line (this is the password)
                lineFind = readEmployeeData.readLine();
                  
            }
            
        } catch(Exception e) {
            System.out.println(e); // no further handler necessary
        } // end try-catch for adding employees to combo box
        
        // add employee elemetns to combo box
        selectEmployee.getItems().addAll(employees);        
    } // end initialize method   
}
