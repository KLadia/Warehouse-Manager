/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;


public class ReassignTaskFrameController implements Initializable {
    
    // set of employees (no duplicates allowed)
    static Set<String> employees = new HashSet<String>();
    
    @FXML
    private Label reassignedOrNo; // for success or fail message
    
    @FXML
    private TextField task;
    
    @FXML
    private ComboBox selectEmployee;
    
    @FXML
    private DatePicker date;
    
    @FXML
    private Button reassign;
    
    @FXML
    private void handleReassign(ActionEvent event) throws IOException {
        if(task.getText().startsWith(" ") || date.getEditor().getText().equals("") ||
                task.getText().equals("") || date.getEditor().getText().startsWith(" ") ||
                selectEmployee.getSelectionModel().isEmpty()) {
            
            reassignedOrNo.setText("Something went wrong");
            reassignedOrNo.setTextFill(Color.RED);
        }
        else {
        // this removes tasks
        File inputFile = new File("Tasks.txt");
        File tempFile = new File("temp.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
        
        // find initial task to remove based on task from manager frame selection
        String initialTask = ManagerFrameController.reassignTaskText;
        String firstLine; // date

        while((firstLine = reader.readLine()) != null) {
            String secondLine = reader.readLine();
            String thirdLine = reader.readLine();
            
            // trim newline when comparing with initial task
            String trimmedLine = thirdLine.trim();
            
            if(trimmedLine.equals(initialTask)) continue;
            // update text file
            writer.write(firstLine + System.getProperty("line.separator") + 
                    secondLine + System.getProperty("line.separator") + thirdLine + 
                    System.getProperty("line.separator"));
            
        }
        writer.close(); 
        reader.close(); 
        boolean successful = tempFile.renameTo(inputFile);
        // end task removal
        
        // adding the reassigned task
        File taskData = new File("Tasks.txt");
        try {
                FileWriter data = new FileWriter(taskData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(date.getEditor().getText());
                storeData.newLine();
                storeData.append(selectEmployee.getValue().toString());
                storeData.newLine();
                storeData.append(task.getText());
                storeData.newLine();
                storeData.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
        
        reassignedOrNo.setText("Task successfully reassigned");
        
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        task.setText(ManagerFrameController.reassignTaskText);
        
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind;
        try {
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
            while((lineFind = readEmployeeData.readLine()) != null) {
                    
                employees.add(new String(lineFind));
                lineFind = readEmployeeData.readLine();
                  
            }
            
        } catch(Exception e) {
            System.out.println(e);
        }
        
        selectEmployee.getItems().addAll(employees);        
    }    
    
}
