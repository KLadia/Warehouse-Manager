/* 
 * approveinventoryremovalcontroller.java
 *
 * This is just a popup with an approve button to allow inventory to be cleared.
 * Hitting the approve button automatically clears inventory stats. This action
 * cannot be undone by the manager. Accessed from load inventory data frame.
 *
 * @author : chelseaatkins (Nov 18 2017)
 *
 * @SQA    : danielafuenzalida (last tested Nov 11 2017)
 *
 */

package warehousemanagementsystem;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ApproveInventoryRemovalController implements Initializable {
    
    @FXML
    private Label notification; // successful message label
    
    // for handling approve clear inventory button action
    @FXML
    private void handleApprove(ActionEvent event) throws IOException {
        // this overwrites everything in inventory file and clears it
        PrintWriter writeNew = new PrintWriter(new File("Inventory.txt"));
        writeNew.print("");
        writeNew.close();
        
        // this overwrites everything in completed inventory file and clears it
        PrintWriter writeComplete = new PrintWriter(new File("InventoryCompleted.txt"));
        writeComplete.print("");
        writeComplete.close();
        
        // set label text so user knows inventory has been cleared
        notification.setText("Inventory successfully cleared");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // no initialization code needed
    }    
    
}
