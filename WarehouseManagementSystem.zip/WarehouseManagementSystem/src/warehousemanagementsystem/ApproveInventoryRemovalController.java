package warehousemanagementsystem;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class ApproveInventoryRemovalController implements Initializable {
    
    @FXML
    private Label notification;
    
    @FXML
    private void handleApprove(ActionEvent event) throws IOException {
        PrintWriter writeNew = new PrintWriter(new File("Inventory.txt"));
        writeNew.print("");
        writeNew.close();
        
        PrintWriter writeComplete = new PrintWriter(new File("InventoryCompleted.txt"));
        writeComplete.print("");
        writeComplete.close();
        
        notification.setText("Inventory successfully cleared");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
