package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class RemoveEmployeeFrameController implements Initializable {
    
    @FXML
    private ComboBox selectEmployee;
    
    @FXML
    private Label successfullyRemoved;
    
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    // TODO: fix this as it currently erases all employees
    @FXML
    private void handleRemove(ActionEvent event) throws IOException {
        
        /*File modifyEmployeeData = new File("StoredDataEmployee.txt");
        
        String toRemove = ((String)selectEmployee.getSelectionModel().getSelectedItem());
        
        BufferedReader reader = new BufferedReader(new FileReader(modifyEmployeeData));
        String line = reader.readLine();
        String newContent;
        FileWriter writer = new FileWriter(modifyEmployeeData);
        while (line != null) {
            if(line.equals(toRemove)) {
                newContent = toRemove.replace(toRemove, "");
                writer.write(newContent);
            }
            line = reader.readLine();
        }
        writer.close();
        reader.close();*/
        
        File inputFile = new File("StoredDataEmployee.txt");
        File tempFile = new File("myTempFile.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

        String lineToRemove = ((String)selectEmployee.getSelectionModel().getSelectedItem());
        String currentLine;

        while((currentLine = reader.readLine()) != null) {
            // trim newline when comparing with lineToRemove
            String trimmedLine = currentLine.trim();
            String nextLine = reader.readLine();
            if(trimmedLine.equals(lineToRemove)) continue;
            
            writer.write(currentLine + System.getProperty("line.separator")+ nextLine + System.getProperty("line.separator"));
            
        }
        writer.close(); 
        reader.close(); 
        boolean successful = tempFile.renameTo(inputFile);

        successfullyRemoved.setText("Employee has been successfully removed");
    }
    
    // initialize controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Set<String> employees = new HashSet<String>();
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind;
        try {
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
            while((lineFind = readEmployeeData.readLine()) != null) {
                    
                employees.add(new String(lineFind));
                lineFind = readEmployeeData.readLine();
                  
            }
            
        } catch(Exception e) {
            System.out.println(e);
        }
        
        selectEmployee.getItems().addAll(employees);
        
    }
                
    
}
