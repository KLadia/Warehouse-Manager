/* 
 * removeemployeeframecontroller.java
 *
 * This class allows the manager to select an employeefor removal and then approve
 * the removal of that employee from the system. That employee will no longer be
 * able to log in but all of their associated tasks and announcements will still
 * show as stored information.
 *
 * @author : andrewaaran (Sep 1 2017)
 *
 * @SQA    : kristinladia (tested on Sep 20 2017)  - this currently removes all employees
 *           and not just the selected one
 * @SQA    : danielafuenzalida (last tested on Nov 30)
 *
 * @update : chelseaatkins (Sep 22 2017) - fixed employee removal issue
 * 
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class RemoveEmployeeFrameController implements Initializable {
    
    @FXML
    private ComboBox selectEmployee; // combo box to select employee to remove
    
    @FXML
    private Label successfullyRemoved; // notification message success or error
    
    // for handling the back to manager frame hyperlink
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        // create new parent scene for manager frame
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    // handle when the manager hits the remove button
    @FXML
    private void handleRemove(ActionEvent event) throws IOException {
        
        // file to read and write from
        File inputFile = new File("StoredDataEmployee.txt");
        
        // temporary file to store information before overwriting with original
        File tempFile = new File("myTempFile.txt");
        
        // creating readers and writers for looping through elements in file
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

        // fine the line that needs to be remove in the file (the employee username)
        String lineToRemove = ((String)selectEmployee.getSelectionModel().getSelectedItem());
        
        // variable for reading through file
        String currentLine;
        
        // loop through each line in the file until null
        while((currentLine = reader.readLine()) != null) {
            
            // trim newline when comparing with lineToRemove
            String trimmedLine = currentLine.trim();
            String nextLine = reader.readLine();
            
            // check if trimmedline is the same as the line that needs to be removed
            // if not do not continute the loop
            if(trimmedLine.equals(lineToRemove)) continue;
            
            // overwrite the username line from linetoremove and the next line
            // because it contains the corresponding user's password
            writer.write(currentLine + System.getProperty("line.separator") + 
                    nextLine + System.getProperty("line.separator"));
            
        }
        writer.close(); // close writer
        reader.close(); // close reader
        
        // rename temporary file to new input file name
        boolean successful = tempFile.renameTo(inputFile);
        
        // update notification label text with success message
        successfullyRemoved.setText("Employee has been successfully removed");
    }
    
    // initialize controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // hash set for storing employee information
        // uses hash set to prevent duplicates
        Set<String> employees = new HashSet<String>();
        
        // file to read from
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        
        // variable used for reading through the file
        String lineFind;
        
        try {
            // creating readers for looping through the file
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
            
            // looping through file line by line
            while((lineFind = readEmployeeData.readLine()) != null) {
                // add each new line to the employees
                employees.add(new String(lineFind));
                // read the next line in order to add it to the file
                lineFind = readEmployeeData.readLine(); 
            }
        } catch(Exception e) {
            System.out.println(e); // no further handler necessary 
        } // end try-catch block  for reading employee data file
        
        // add all employees to combo box
        selectEmployee.getItems().addAll(employees);
        
    }         
}
