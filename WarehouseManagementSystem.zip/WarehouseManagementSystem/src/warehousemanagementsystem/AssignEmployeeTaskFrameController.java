/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AssignEmployeeTaskFrameController implements Initializable {
    
    // employees set (hash set to remove duplicates on initializable)
    static Set<String> employees = new HashSet<String>();
    
    @FXML
    private ComboBox selectEmployee;
    
    @FXML
    private ComboBox selectEmployee2;
    
    @FXML
    private ComboBox selectEmployee3;
    
    @FXML
    private TextField task1;
    
    @FXML
    private TextField task2;
    
    @FXML
    private TextField task3;
    
    @FXML
    private DatePicker date1;
    
    @FXML
    private DatePicker date2;
    
    @FXML
    private DatePicker date3;
    
    @FXML
    private Label notification1;
    
    @FXML
    private Label notification2;
    
    @FXML
    private Label notification3;

    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    @FXML
    private void handleAssign1(ActionEvent event) throws IOException {
        
        File storedData = new File("Tasks.txt");
        String storedTask1;
        String storedDate1;
        String assignedEmployee1;
        
        storedTask1 = task1.getText();
        storedDate1 = date1.getEditor().getText();
        assignedEmployee1 = selectEmployee.getValue().toString();
        
        if(task1 == null || storedTask1.equals("") || storedDate1 == null || storedDate1.equals("")) {
            notification1.setText("Something went wrong: Please fill out all fields");
        }
        else {
            try {
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(storedDate1);
                storeData.newLine();
                storeData.append(assignedEmployee1);
                storeData.newLine();
                storeData.append(storedTask1);
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            notification1.setText("Task successfully created");
            
            // reset tht text fields and text areas
            task1.setText(null);
            date1.getEditor().setText(null);
        }
    }
    
    @FXML
    private void handleAssign2(ActionEvent event) throws IOException {
        File storedData = new File("Tasks.txt");
        String storedTask2;
        String storedDate2;
        String assignedEmployee2;
        
        storedTask2 = task2.getText();
        storedDate2 = date2.getEditor().getText();
        assignedEmployee2 = selectEmployee2.getValue().toString();
        
        if(task2 == null || storedTask2.equals("") || storedDate2 == null || 
                storedDate2.equals("")) {
            notification2.setText("Something went wrong: Please fill out all fields");
        }
        else {
            try {
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(storedDate2);
                storeData.newLine();
                storeData.append(assignedEmployee2);
                storeData.newLine();
                storeData.append(storedTask2);
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            notification2.setText("Task successfully created");
            
            // reset tht text fields and text areas
            task2.setText(null);
            date2.getEditor().setText(null);
        }
    }
    
    @FXML
    private void handleAssign3(ActionEvent event) throws IOException {
        File storedData = new File("Tasks.txt");
        
        String storedTask3;
        String storedDate3;
        String assignedEmployee3;
        
        storedTask3 = task3.getText();
        storedDate3 = date3.getEditor().getText();
        assignedEmployee3 = selectEmployee3.getValue().toString();
        
        if(selectEmployee3.getSelectionModel().isEmpty()) {
            notification3.setText("Something went wrong: Please select an employee");
        }
        if(task3 == null || storedTask3.equals("") || storedDate3 == null || 
                storedDate3.equals("")) {
            notification3.setText("Something went wrong: Please fill out all fields");
        }
        else {
            try {
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(storedDate3);
                storeData.newLine();
                storeData.append(assignedEmployee3);
                storeData.newLine();
                storeData.append(storedTask3);
                storeData.newLine();
                storeData.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            notification3.setText("Task successfully created");
            
            // reset tht text fields and text areas
            task3.setText(null);
            date3.getEditor().setText(null);
        }
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind;
        try {
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
            while((lineFind = readEmployeeData.readLine()) != null) {
                    
                employees.add(new String(lineFind));
                lineFind = readEmployeeData.readLine();
                  
            }
            
        } catch(Exception e) {
            System.out.println(e);
        }
        
        selectEmployee.getItems().addAll(employees);
            selectEmployee.getItems().addAll("All Managers", "All Employees");  
            selectEmployee2.getItems().addAll(employees);
            selectEmployee2.getItems().addAll("All Managers", "All Employees");
            selectEmployee3.getItems().addAll(employees);
            selectEmployee3.getItems().addAll("All Managers", "All Employees"); 
    }    
}
