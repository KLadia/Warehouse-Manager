/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AssignEmployeeTaskFrameController implements Initializable {
    private String[] employeeArray = new String[20];
    
    @FXML
    private ComboBox selectEmployee;
    
    @FXML
    private TextField task1;
    
    @FXML
    private TextField task2;
    
    @FXML
    private TextField task3;
    
    @FXML
    private TextField task1Details;
    
    @FXML
    private TextField task2Details;
    
    @FXML
    private TextField task3Details;
    
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        String lineFind;
        try {
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
            for(int i = 0; i < employeeArray.length; i++) {
                while((lineFind = readEmployeeData.readLine()) != null) {
                    String nextLineFind = readEmployeeData.readLine();
                    employeeArray[i] = (lineFind + " " + nextLineFind);
                    selectEmployee.getItems().addAll(employeeArray[i]);
                    }
            }
            selectEmployee.getItems().addAll("Select an employee");    
        } catch(Exception e) {
            System.out.println(e);
        }  
    }    
}
