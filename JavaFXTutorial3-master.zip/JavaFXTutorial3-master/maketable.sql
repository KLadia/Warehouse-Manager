CREATE TABLE Users (USERNAME TEXT PRIMARY KEY     NOT NULL, 
                    PASSWORD       TEXT     NOT NULL );
					
