/* 
 * managerframecontroller.java
 *
 * The manager frame has the following tabs: dashboard, inventory, imports,
 * exports, and admin functions. The dashboard features a section for tasks
 * assigned to employees for that day and shows who the task is assigned to 
 * as well as the description. It also has a section for overdue tasks that the
 * manager has the ability to reassign. On the right are employee task notifications
 * and a percentage that displays the tasks completed for that day. The import and
 * export tabs feature accordions with drop down titled panes to view label or
 * product info. The manager can load inventory information through the inventory
 * tab and access their administrative controls (remove or create account,
 * announcements, assign task) from the admin tab.
 *
 * @author : chelseaatkins (Sep 15 2017)
 *
 * @SQA    : kristinladia (tested on Oct 20) - what happens to overdue tasks
 * @SQA    : danielafuenzalida (tested on Dec 1) - tasks do not work for single 
 *           digit days or months
 * @SQA    : danielafuenzalida (last tested Dec 3 2017)
 *
 * @update : andrewaaran (Oct 21 2017) - reassign funcitonality for overdue task
 * @update : chelseaatkins (Dec 2 2017) - fixed single digit month/day tasks
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class ManagerFrameController implements Initializable {
    
    // access who the logged in user is from loginFrameController
    String user = LoginFrameController.enteredUsername;
    
    // calculate percentage of completed tasks based off of employee frame variables
    int percentage = (int) Math.round((EmployeeFrameController.taskComplete / 
            EmployeeFrameController.taskCount) * 100);
    
    // these need to be static to be accessed in the reassign task frame
    // for when the manager checks an overdue task to be reassigned
    static String reassignTaskText;
    static String reassignEmployee;
    static String reassignDate;
    
    @FXML
    private Label title; // label welcome message
    
    @FXML
    private Label percentComplete; // label to display percentage of completed tasks
    
    @FXML
    private Label onDate; // label for putting the current date under percentage
    
    @FXML
    private Accordion imports; // for holding the imports titled panes
    
    @FXML
    private Accordion exports; // for holding the exports titled panes
    
    @FXML
    private VBox notifyManager; // for holding the manager notification elements
    
    @FXML
    private Label notifications; // to set the text with manager notification elements
    
    @FXML
    private VBox today; // to hold the tasks assigned to employees for the day
    
    @FXML
    private Label taskText; // to set the text of employee tasks assigned that day
    
    @FXML
    private VBox upcoming; // to hold overdue tasks
    
    @FXML
    private ScrollPane todaysTasks; // so that today's tasks will scroll
    
    @FXML
    private ScrollPane nextTasks; // so that over task's will scroll
    
    @FXML
    private BarChart inventory; // for the inventory bar chart 
    
    @FXML
    private CategoryAxis category; // for the category axis on the bar chart
    
    @FXML
    private NumberAxis numbers; // for the numbers axis on the bar chart
    
    @FXML
    private Label inventoryLastUpdate; // label to hold last inventory update date
    
    @FXML
    private ProgressBar pb; // inventory overall progress bar
    
    @FXML
    private VBox forChart; // holds the inventory data bar chart
    
    // handle the logout hyperlink at the top of the manager frame
    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        // set the login frame as the parent scene
        Parent logoutFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
        Scene logoutFrameScene = new Scene(logoutFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        logoutFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getLogoutFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getLogoutFrame.setScene(logoutFrameScene);
        getLogoutFrame.show();
        
        // create the logout success popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LogoutFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    // handle load inventory data hyperlink from inventory tab in manager
    @FXML
    private void handleLoadInventory(ActionEvent event) throws IOException {
        // create the popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("LoadInvetoryData.fxml"));
        // @daniela : add css style sheet
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        // end css resource
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
        
        // refresh manager frame when popup is closed to show new bar chart components
        dialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    // set manager frame as background parent scene
                    Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
                    Scene managerFrameScene = new Scene(managerFrame);
                    // @daniela : add css style sheet
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    managerFrameScene.getStylesheets().add(css);
                    // end css resource
                    Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    getManagerFrame.setScene(managerFrameScene);
                    getManagerFrame.show();
                } catch (IOException e) {
                    // catch message not necessary
                }
            }
        }); // end manager frame refresh
    }
    
    // handle create account hyperlink accessed from admin functions
    @FXML
    private void handleCreateAccount(ActionEvent event) throws IOException {
        // set create account frame as new parent scene
        Parent createAccountFrame = FXMLLoader.load(getClass().getResource("CreateAccountFrame.fxml"));
        Scene createAccountScene = new Scene(createAccountFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createAccountScene.getStylesheets().add(css);
        // end css resource
        Stage getCreateAccountFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAccountFrame.setScene(createAccountScene);
        getCreateAccountFrame.show();
        
    }
    
    // handle assign employee task hyperlink accessed from admin functions
    @FXML
    private void handleAssignEmployeeTask(ActionEvent event) throws IOException {
        // set assign employee task frame as new parent scene
        Parent assignEmployeeTaskFrame = FXMLLoader.load(getClass().getResource("AssignEmployeeTaskFrame.fxml"));
        Scene assignEmployeeTaskScene = new Scene(assignEmployeeTaskFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        assignEmployeeTaskScene.getStylesheets().add(css);
        // end css resource
        Stage getassignEmployeeTaskFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getassignEmployeeTaskFrame.setScene(assignEmployeeTaskScene);
        getassignEmployeeTaskFrame.show();
        
    }
    
    // handle remove employee frame link access from admin functions
    @FXML
    private void handleRemoveEmployee(ActionEvent event) throws IOException {
        // set remove employee frame as new parent scene
        Parent removeEmployeeFrame = FXMLLoader.load(getClass().getResource("RemoveEmployeeFrame.fxml"));
        Scene removeEmployeeScene = new Scene(removeEmployeeFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        removeEmployeeScene.getStylesheets().add(css);
        // end css resource
        Stage getRemoveEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getRemoveEmployeeFrame.setScene(removeEmployeeScene);
        getRemoveEmployeeFrame.show();
        
    }
    
    // handle create announcement link accessed from admin fucntions
    @FXML
    private void handleCreateAnnouncement(ActionEvent event) throws IOException {
        // set create announcement frame as new parent scene
        Parent createAnnouncementFrame = FXMLLoader.load(getClass().getResource("CreateAnnouncementFrame.fxml"));
        Scene createAnnouncementScene = new Scene(createAnnouncementFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createAnnouncementScene.getStylesheets().add(css);
        // end css resource
        Stage getCreateAnnouncementFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getCreateAnnouncementFrame.setScene(createAnnouncementScene);
        getCreateAnnouncementFrame.show();
    }
    
    // handle view all notifications link accessed from manager dashboard
    @FXML
    private void handleViewAllNotifications(ActionEvent event) throws IOException {
        // creates a popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ViewAllNotifications.fxml"));
        // @daniela : add css style sheet
        Scene createLabelScene = new Scene(createLabelFrame);
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        // end css resource
        createLabelScene.getStylesheets().add(css);
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    // execute this method everytime the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // set the welcome message text to welcome logged in user
        title.setText("Welcome, " + user);     
        
        // set percentage label text
        percentComplete.setText(Integer.toString(percentage) + "%");
        
        // set inventory update text
        inventoryLastUpdate.setText(" ");
        
        // getting date to display on the manager dash
        Date todaysDate = new Date();
        DateFormat dateForDash = new SimpleDateFormat("E MMM dd yyyy");
        String dashDate = dateForDash.format(todaysDate);
        onDate.setText(dashDate); // set ondate text
        
        // set background of scollers to transparent
        todaysTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        nextTasks.setBackground(new Background(
                new BackgroundFill(Color.TRANSPARENT, null, null)));
        
        // updates notifications on manager dashboard
        File notificationsData = new File("Notifications.txt"); // file to read from
        
        try{
            // create reader elements to loop through file lines
            FileReader readNotifications = new FileReader(notificationsData);
            BufferedReader readData = new BufferedReader((readNotifications));
            
            // variables for reading through file
            String lineFind; // used for reading through file
            String notify = ""; // will be used to set label text later
            
            // temporarily stores and formats all notifications from file
            List<String> temp = new ArrayList<String>();
            
            // read through each line of file until null
            while((lineFind = readData.readLine()) != null) { // reading through file
                temp.add(lineFind); // add each line in the file to array list
            }
            // search through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent notification at the top
                notify += (temp.get(i) + System.lineSeparator());
                notifications.setText(notify); // set label text
            }
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } 
        
        // for updating the imports tab
        File importsData = new File("Imports.txt"); // file to read from
        
        try{
            // reader elements for looping through file
            FileReader readImports = new FileReader(importsData);
            BufferedReader readData = new BufferedReader((readImports));
            
            // vairable used to read file line by line
            String lineFind;
            
            // titled panes for storing import inofrmation
            // dynamically added as file as more lines
            List<TitledPane> panes = new ArrayList<TitledPane>();
            
            // read through file until null
            while((lineFind = readData.readLine()) != null) {
                
                // add the first line as the titled of the pane and following lines
                // as information to display under the pane dropdown
                panes.add(new TitledPane(lineFind, new Label(readData.readLine()
                        + System.lineSeparator() + readData.readLine() +
                         System.lineSeparator() + readData.readLine())));
                // no variables stored as file is read, just append to data with
                // the readLine() fucntionality
               
            }
            
            // add all titled panes to the imports accordion
            imports.getPanes().addAll(panes);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } // end try-catch block for reading imports
        
        
        // for updating the exports tab
        File exportsData = new File("Exports.txt"); // file to read from
        
        try{
            // creating readers for loopng through file lines
            FileReader readExports = new FileReader(exportsData);
            BufferedReader readExportsData = new BufferedReader((readExports));
            
            // variable used for reading through file line by line
            String lineX;
            
            // hold the new panes created in a dynamic list
            List<TitledPane> newPane = new ArrayList<TitledPane>();
            
            // read through all lines in file until null
            while((lineX = readExportsData.readLine()) != null) {
               
                // behave like the imports adding, no vars stored just read
                // each new line and add where the first line is the titled
                // pane's title
                newPane.add(new TitledPane(lineX, new Label(readExportsData.readLine()
                        + System.lineSeparator() + readExportsData.readLine() + 
                        System.lineSeparator() + readExportsData.readLine())));
               
            }
            
            // add all titled panes to the exports accordion
            exports.getPanes().addAll(newPane);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } // end try-catch block for reading exports
        
        
        
        // for updating the tasks sections
        File tasksData = new File("Tasks.txt");
        
        // getting current date for comparison
        DateTimeFormatter d = DateTimeFormatter.ofPattern("M/d/yyyy");
        LocalDate localDate = LocalDate.now(); // today's date
        LocalDate weekToday = localDate.plusWeeks(1); // next week
        LocalDate weeksAgo = localDate.minusWeeks(52); // previous week
       
        // turning date into string
        String date = d.format(localDate);
        
        // hold today's tasks in checkbox form
        List<CheckBox> tasks = new ArrayList<CheckBox>();
        
        // hold overdue tasks
        List<CheckBox> upcomingTasks = new ArrayList<CheckBox>();
        
        // hold  information from tasks
        List<Label> taskStuff = new ArrayList<Label>();
        
        try{
            // creating readers to loop through files
            FileReader readTasks = new FileReader(tasksData);
            BufferedReader readTasksData = new BufferedReader((readTasks));
            
            // vairable used to read through each line in the file
            String liner;
            
            // local date for parsing string date found in file
            LocalDate dateInFile;
            
            // loop through file until null
            while((liner = readTasksData.readLine()) != null) {
                
                // another try-catch is necessary for date parsing
                try {
                    // parse date in file to lcoal date for comparison
                    dateInFile = LocalDate.parse(liner, d);
                    
                    // compare parsed local date to today's date
                    if(date.equals(liner)) {
                        
                        // if yes proceed to read rest of lines
                        liner = readTasksData.readLine();
                        String whosTask = liner; // who its assigned to
                        liner = readTasksData.readLine(); // task information
                        
                        // add a new label to the taskStuff with assigned to and info
                        taskStuff.add(new Label(whosTask + ": " + liner + System.lineSeparator()));
                        
                        // @chelsea : for my reference
                        // taskText.setText(whosTask + ": " + liner + System.lineSeparator());  
                    }
                    
                    // if we're here, then we need to check for overdue tasks
                    else {
                        // for overdue tasks (yes it says upcoming, disregard)
                        // check if a task is overdue
                        if(localDate.compareTo(dateInFile) >= 0 && dateInFile.compareTo(weeksAgo) > 0){
                            String who = readTasksData.readLine(); // this is the user
                            liner = readTasksData.readLine(); // this is the task information
                            
                            // display a new checkbox
                            // contains task details and who it was assigned to
                            upcomingTasks.add(new CheckBox(liner + " assigned to " + who));
                        }
                    } // end conditional block for checking task dates
                
                } catch (Exception e) {
                    // Throw invalid date message
                } // end try-catch for date parsing
            } // end while loop for reading through file
            
            // add all of the labels to the today section
            today.getChildren().addAll(taskStuff);
            
            // add all of the overdue tasks to the overdue task section
            upcoming.getChildren().addAll(upcomingTasks);
            
        } catch(Exception e) {
            System.out.println(e);
        } // end try-catchfor file readers
        
        // handler for checking and unchecking tasks
        // array list checked handles events for dynamic list of checkboxes
        EventHandler checked = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                
                // read the information stored int he voer due tasks array list
                for (int i = 0; i < upcomingTasks.size(); i++) {
                    
                    // check if the overdue task has been selected
                    if (event.getSource() == upcomingTasks.get(i)) {
                        
                        // we only want the task deatils before the 'assigned' portion
                        int quit_position = upcomingTasks.get(i).getText().indexOf(" assigned");
                        if (quit_position >= 0) {
                            // assign the string with the task details up to assigned
                            reassignTaskText = upcomingTasks.get(i).getText().substring(0, quit_position);
                        }
                        else {
                            // otherwise set the text from the checkbox element
                            reassignTaskText = upcomingTasks.get(i).getText();
                        }
                        
                        // regsiter event handler for a checked overdue task
                        try {
                            handleReassign(event); // regsiter event handler
                            
                        } catch (IOException e) {
                            System.out.println(e); // no further handler necessary
                        } // end try-catch for handling reassign event
                    }
                }
            }
        }; // end event handler for checked task
        
        
        // register event handlers for overdue and today's tasks
        for (int i = 0; i < upcomingTasks.size(); i++) { // adding action handlers
            upcomingTasks.get(i).setOnAction(checked);
        }
        for (int i = 0; i < tasks.size(); i++) { // adding action handlers
            tasks.get(i).setOnAction(checked);
        }
        
       
        // for inventory double bar chart
        // create bar chart with category axis of string and number axis of integers
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> sbc = new BarChart<String, Number>(xAxis, yAxis);
        
        // create series for inventory items and completed items
        XYChart.Series<String, Number> series1 = new XYChart.Series<String, Number>();
        XYChart.Series<String, Number> series2 = new XYChart.Series<String, Number>();
        
        // set the axis label text
        xAxis.setLabel("Component");
        yAxis.setLabel("Number of Items");
        
        // set the series name text
        series1.setName("Incomplete Items");
        series2.setName("Inventoried Items");
        
        // we need to read through inventory.txt
        try{
            // create file readers to loop through file line by line
            FileReader readInventory = new FileReader(new File("Inventory.txt"));
            BufferedReader readInventoryData = new BufferedReader((readInventory));
            
            // variables used for reading through file
            String line;
            String nextLine;
            
            // read through file until null
            while((line = readInventoryData.readLine()) != null) {
                // line is implicitly read in the while conditional
                // it stores the component item
                // nextLine contains the items in that component and needs to be parsed
                nextLine = readInventoryData.readLine();
                
                // add the data to the series with component and parsed items
                series1.getData().add(new XYChart.Data(line, Integer.parseInt(nextLine)));
            }
            
        } catch (Exception e) { 
            System.out.println(e); // no further handler necessary
        } // end try-catch for reading inventory.txt
        
        // read through inventory completed to get info for second series
        try{
            // create reader elements to loop through file line by line
            FileReader readInventory = new FileReader(new File("InventoryCompleted.txt"));
            BufferedReader readInventoryData = new BufferedReader((readInventory));
            
            // variables used for looping through file
            String line;
            String nextLine;
            
            // read each line until null
            while((line = readInventoryData.readLine()) != null) {
                // line is implicitly read in the while conditional
                // it stores the component item
                // nextLine contains the items completed in component
                // it needs to be parsed
                nextLine = readInventoryData.readLine();
                
                // addthe completed data to the series with parsed completed items
                series2.getData().add(new XYChart.Data(line, Integer.parseInt(nextLine)));
            }
            
        } catch (Exception e) { 
            System.out.println(e); // no further handler necessary
        } // end try-catch for reading completed inventory items
        
        // add all the data from series one and two to the bar chart
        sbc.getData().addAll(series1, series2);
        
        // throw the chart in its designated vbox
        forChart.getChildren().addAll(sbc);
    }
    
    // handler for when the manager checks an overde task to be reassigned
    // see the checked task handler for how this is implemented
    @FXML
    private void handleReassign(ActionEvent event) throws IOException {
        // create the reassign task popup
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ReassignTaskFrame.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        // end css resource
        dialog.setScene(createLabelScene);
        dialog.show();
        
        // refresh the manager dashboard after closing the reassign popup (shows updated tasks)
        dialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    // refresh the manager frame parent scene in the background
                    Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
                    Scene managerFrameScene = new Scene(managerFrame);
                    // @daniela : add css style sheet
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    managerFrameScene.getStylesheets().add(css);
                    // end css resource
                    Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    getManagerFrame.setScene(managerFrameScene);
                    getManagerFrame.show();
                } catch (IOException e) {
                    // catch message
                }
            }
        }); // end refresh manager page
        
    } // end method for handling reassign
    
}
