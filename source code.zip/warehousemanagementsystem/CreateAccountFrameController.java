/* 
 * createaccountframecontroller.java
 *
 * This frame can only be accessed by a manager. This allows the manager to create
 * a new employee account or a new manager account. It writes this information to
 * either storeddataemployee.txt or storeddatamanager.txt based on input.
 *
 * @author : chelseaatkins (Sep 10 2017)
 *
 * @SQA    : kristinladia (tested Sep 22 2017) - no input vaidation
 * @SQA    : danielafuenzalida (tested Oct 30) - does not check if username exists
 *
 * @update : chelseaatkins (Oct 1 2017) - added input validation
 * @update : chelseaatkins (Nov 3 2017) - added username exists validation
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import static warehousemanagementsystem.LoginFrameController.enteredUsernameEmp;

public class CreateAccountFrameController implements Initializable {
    
    @FXML
    private RadioButton chooseEmployee; // radio button for employee
    
    @FXML
    private RadioButton chooseManager; // radio button for manager
    
    @FXML
    private Label topNote; // notification label under radio buttons
    
    @FXML
    private Label bottomNote; // notification label at bottom of screen
    
    @FXML
    private TextField userNameField; // user name field
    
    @FXML
    private TextField passwordField; // password field
    
    @FXML
    private TextField confirmField; // confirm password field
    
    // handler for selecting the back hyperlink at the top of the screen
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        // takes you back to the manager frame
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    
    // handler for when the user clicks the create account button
    @FXML
    private void handleCreate(ActionEvent event) throws IOException {
        
        // validating input : fields left empty
        if(userNameField.getText().startsWith(" ") || passwordField.getText().startsWith(" ")
                || userNameField.getText().equals("") || passwordField.getText().equals("")) {
            // update label
            bottomNote.setText("Please fill in all fields");
        }
        else {
           bottomNote.setText(" ");
        }
        
        // validating input : no account type selected
        if (!(chooseEmployee.isSelected()) && !(chooseManager.isSelected())) {
            // update label
            topNote.setText("Please choose an account type");
        }
        // validate input : more than one account type selected
        if (chooseEmployee.isSelected() && chooseManager.isSelected()) {
            topNote.setText("Please only choose one account type"); // update label
        }
        // creating an employee account : everything good, check employee is selected
        else if(chooseEmployee.isSelected() && !(chooseManager.isSelected())) {
            topNote.setText(" ");
            bottomNote.setText(" ");
            
            // Chelsea :
            // start the checking... I literally have no idea how this works
            // @Crick.E.T. I figured this out through sheer luck and trial and error
            // @SQA multiple test results needed
            
            // get information from GUI elements
            String storedUsername = userNameField.getText();
            String storedPassword = passwordField.getText();
            
            // we need to read from both files to ensure a username does not already exist
            File storedDataEmployee = new File("StoredDataEmployee.txt");
            File storedDataManager = new File("StoredDataManager.txt");
            
            try{
                // file readers for employee comparison
                FileReader readEmpData = new FileReader(storedDataEmployee);
                BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
                // for manager comparison (checking username exists)
                FileReader readManData = new FileReader(storedDataManager);
                BufferedReader readManagerData = new BufferedReader((readManData));
                
                // lines for reading through file
                String line; // this is the employee reading
                String otherLine; // this is the manager reading
                
                boolean userExists = false; // keep track of whether the user exists
                
                // begin reading through file, we need to read through both manager and employee
                while((line = readEmployeeData.readLine()) != null) {
                    while((otherLine = readManagerData.readLine()) != null) {
                        // check is the entered username is the same in either employee or manager
                        if(storedUsername.equals(line) || storedUsername.equals(otherLine)) {
                            bottomNote.setText("Username already used"); // if yes update label
                            userExists = true; // update boolean variable
                            break; // break loop
                        }
                    }
                }
                if(!userExists) { // boolean variable must be false in order to create an account
                    
                    // if this is correct we can start writing to the file
                    FileWriter data = new FileWriter(storedDataEmployee, true); // writer
                    BufferedWriter storeData = new BufferedWriter(data); // bufferedwriter
                    storeData.append(storedUsername); // first line stored username
                    storeData.newLine();
                    storeData.append(storedPassword); // second line stores password
                    storeData.newLine();
                    storeData.close(); // close writer
                    
                    // back to login with success message
                    Parent loginFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
                    Scene loginFrameScene = new Scene(loginFrame);
                    
                    // @daniela: add css style sheet
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    loginFrameScene.getStylesheets().add(css);
                    Stage getLoginFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    // end css resource
                    getLoginFrame.setScene(loginFrameScene);
                    getLoginFrame.show();
                    
                    // create the popup success message
                    final Stage dialog = new Stage();
                    dialog.initModality(Modality.APPLICATION_MODAL);
                    Parent createLabelFrame = FXMLLoader.load(getClass().getResource(
                            "SuccessfulAccountCreation.fxml"));
                    Scene createLabelScene = new Scene(createLabelFrame);
                    //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    createLabelScene.getStylesheets().add(css);
                    dialog.setScene(createLabelScene);
                    dialog.show();
                }
            } catch(Exception e) {
                System.out.println(e); // no further handler necessary
            }
        } // end writing to employee data file, information has been successully updated
        
        // creating a manager account : everything good
        else if(chooseManager.isSelected() && !(chooseEmployee.isSelected())) {
            topNote.setText(" ");
            bottomNote.setText(" ");
            
            // start the checking...
            
            // get info from GUI elements
            String storedUsername = userNameField.getText();
            String storedPassword = passwordField.getText();
            
            // reading from both manager and employee files to check username
            File storedDataEmployee = new File("StoredDataEmployee.txt");
            File storedDataManager = new File("StoredDataManager.txt");
            try{
                // for manager comparison
                FileReader readManData = new FileReader(storedDataManager);
                BufferedReader readManagerData = new BufferedReader((readManData));
                
                // for employee comparison (checking username exists)
                FileReader readEmpData = new FileReader(storedDataEmployee);
                BufferedReader readEmployeeData = new BufferedReader((readEmpData));
                
                // line variables for reading through files
                String line; // this line goes through the manager file
                String otherLine; // this line goes through the employee file
                
                boolean userExists = false; // check is username already exists
                
                while((line = readManagerData.readLine()) != null) { // reading manager
                    while((otherLine = readEmployeeData.readLine()) != null) { // reading employee
                        // check is the username is in either empoyee or manager data
                        if(storedUsername.equals(line) || storedUsername.equals(otherLine)) {
                            bottomNote.setText("Username already used"); // bad username, update label
                            userExists = true; // update boolean vairable
                            break; // break the loop, we're done here
                        }
                    }
                }
                
                // the user does not exist, so we can proceed file writing
                if(!userExists) {
                    
                    // writing information to manager file
                    FileWriter data = new FileWriter(storedDataManager, true);
                    BufferedWriter storeData = new BufferedWriter(data);
                    
                    storeData.append(storedUsername); // store username on first line
                    storeData.newLine();
                    storeData.append(storedPassword); // store password on second line
                    storeData.newLine();
                    storeData.close(); // close writer
                    
                    // back to login with success message
                    Parent loginFrame = FXMLLoader.load(getClass().getResource("LoginFrame.fxml"));
                    Scene loginFrameScene = new Scene(loginFrame);
                    // @daniela : add css style sheet
                    String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    loginFrameScene.getStylesheets().add(css);
                    // end css resource
                    Stage getLoginFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    getLoginFrame.setScene(loginFrameScene);
                    getLoginFrame.show();
                    
                    // create the popup success message
                    final Stage dialog = new Stage();
                    dialog.initModality(Modality.APPLICATION_MODAL);
                    Parent createLabelFrame = FXMLLoader.load(getClass().getResource(
                            "SuccessfulAccountCreation.fxml"));
                    Scene createLabelScene = new Scene(createLabelFrame);
                    //String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
                    createLabelScene.getStylesheets().add(css);
                    dialog.setScene(createLabelScene);
                    dialog.show();
                }
            } catch(Exception e) {
                System.out.println(e); // no further handler necessary
            }
        } // end writing manager information to stored data in manager
    }
    
    // initialize controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // no former information necessary to update upon refresh
    }    
    
}
