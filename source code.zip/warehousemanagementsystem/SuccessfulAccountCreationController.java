/* 
 * successfulaccountcreationcontroller.java
 *
 * Just used to display successul account creation message.
 *
 * @author : chelseaatkins (Dec 1 2017)
 *
 */

package warehousemanagementsystem;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class SuccessfulAccountCreationController implements Initializable {
    
    // initializer controller method
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // no method needs to run on page refresh
    }    
    
}
