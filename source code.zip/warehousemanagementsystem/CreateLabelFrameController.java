/* 
 * createlabelframecontroller.java
 *
 * This frame allows the employee to create an export label for an item. They can
 * add a tracking number, item description, and when the estimated delivery date
 * for the item will be. The information is stored to exports.txt and is accessed by
 * both the employee and manager frames to update the export tab on each.
 *
 * @author : chelseaatkins (Sep 12 2017)
 *
 * @SQA    : danielafuenzalida (last tested Dec 1 2017)
 *
 */

package warehousemanagementsystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CreateLabelFrameController implements Initializable {
    
    // enteredUsernameEmp is a static variable from the loginframecontroller
    // accessed here to get the username of who is creating the export label
    String user = LoginFrameController.enteredUsernameEmp;
    
    // these are the variables to get from the GUI elements
    private String storedTracking;
    private String storedDescription;
    private String storedDate;
    
    @FXML
    private Text box; // red X to display over the cardboard box image
    
    @FXML
    private Text boxCheck; // green checkmark to display over cardbaord box
    
    @FXML
    private TextField tracking; // text field for the tracking number
    
    @FXML
    private TextArea description; // text area for product description
    
    @FXML
    private DatePicker date; // date picker for delivery date
    
    @FXML
    private Label confirm; // shows information for success or fail
    
    // these FXML elements display under the cardboard box image
    @FXML
    private Label detailsTracking; // shows confirmation of tracking info
    
    @FXML
    private Label detailsDescription; // shows confirmation of description
    
    @FXML
    private Label detailsDate; // shows confirmation of date
    
    // method to go back to the employee frame scene
    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent employeeFrame = FXMLLoader.load(getClass().getResource("EmployeeFrame.fxml"));
        Scene employeeFrameScene = new Scene(employeeFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        employeeFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getEmployeeFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getEmployeeFrame.setScene(employeeFrameScene);
        getEmployeeFrame.show();
    }
    
    // method to handle when the user clicks verify
    @FXML
    private void handleVerify(ActionEvent event) throws IOException {
        
        // get the current local time to put when the export label was created
        Calendar cal = Calendar.getInstance();
        
        // this is the file we'll be writting to
        File storedData = new File("Exports.txt");
        
        // get the information from the GUI elements
        storedTracking = tracking.getText();
        storedDescription = description.getText();
        storedDate = date.getEditor().getText();
        
        // validating input
        if(tracking == null || date == null || description == null || storedTracking.equals("") ||
           storedDescription.equals("") || storedDate.equals("")) { // empty fields
            box.setVisible(true); // show the red x
            boxCheck.setVisible(false); // hide the green check
            confirm.setText("   Something went wrong"); // set label text to error msg
            detailsDate.setText("Please fill out all fields"); // show the error
            detailsDescription.setText(""); // no info needed for description
        }
        else if((storedTracking.length()) < 10) { // check tracking size
            box.setVisible(true); // show red x
            boxCheck.setVisible(false); // hide green check
            confirm.setText("   Something went wrong"); // set error msg text
            detailsTracking.setText("Incorrect tracking length"); // show error details
            detailsDescription.setText(""); // no info needed here
            detailsDate.setText(""); // no info needed here
        }
        else { // everything is good, write to file
            try {
                // writing to exports.txt
                FileWriter data = new FileWriter(storedData, true);
                BufferedWriter storeData = new BufferedWriter(data);
                
                // all pieces of info will go on a new line
                // tracking, then shipment date, then description
                // store who created the label and the time they made it
                storeData.append("Tracking #: " + storedTracking); // tracking on line 1
                storeData.newLine();
                storeData.append("Shipment Date: " + storedDate); // shipment date on line 2
                storeData.newLine();
                storeData.append("Product Description: " + storedDescription); // description line 3
                storeData.newLine();
                // creation info is the last line, uses the username and local time
                storeData.append("Label Created By: " + user + " on " + cal.getTime());
                storeData.newLine();
                storeData.close(); // close file writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            }
            
            // set up graphics for valid input
            box.setVisible(false); // hide red x
            boxCheck.setVisible(true); // show green checkmark
            confirm.setText("Label successfully created!"); // set success message
            
            // show the details under the image
            // each detail segment has it's own label
            detailsTracking.setText("Tracking #: " + storedTracking);
            detailsDate.setText("Target Shipment Date: " + storedDate);
            detailsDescription.setText("Product Description: " + storedDescription);
            
            // reset tht text fields and text areas and date picker
            tracking.setText(null);
            description.setText(null);
            date.getEditor().setText(null);
        }
        
    }
    
    // run this method everytime the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // we don't want the red x or green check mark to be visible at first
        box.setVisible(false);
        boxCheck.setVisible(false);
    }    
    
}
