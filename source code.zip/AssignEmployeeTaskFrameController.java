/* 
 * assignemployeetaskframcontroller.java
 *
 * This features three different methods that do exactly the same things. The 
 * manager can assign employee a task by selecting an employee from the dropdown
 * menu. They can then choose the date for the employee from the date picker and
 * fill in a short task description. Information stores to the tasks.txt file to
 * be read by both the employee and manager frames.
 *
 * @author : andrewaaran (Oct 20 2017)
 *
 * @SQA    : kristinladia (tested Oct 22 2017) - writes blank tasks to file
 * @SQA    : kristinladia (last tested Oct 24)
 *
 * @update : chelseaatkins (Oct 24 2017) - added input validation
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class AssignEmployeeTaskFrameController implements Initializable {
    
    // employees set (hash set to remove duplicates on initializable)
    static Set<String> employees = new HashSet<String>();
    
    @FXML
    private ComboBox selectEmployee; // top option for select employee
    
    @FXML
    private ComboBox selectEmployee2; // middle option for select employee
    
    @FXML
    private ComboBox selectEmployee3; // bottom option for select employee
    
    @FXML
    private TextField task1; // top task field
    
    @FXML
    private TextField task2; // middle task field
    
    @FXML
    private TextField task3; // bottom task field
    
    @FXML
    private DatePicker date1; // top date select
    
    @FXML
    private DatePicker date2; // middle date select
    
    @FXML
    private DatePicker date3; // bottom date select
    
    @FXML
    private Label notification1; //top success or fail notification
    
    @FXML
    private Label notification2; // middle success or fail notification
    
    @FXML
    private Label notification3; // bottom success or fail notification

    
    // refreshes manager page and load new parent after clicking back hyperlink
    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent managerFrame = FXMLLoader.load(getClass().getResource("ManagerFrame.fxml"));
        Scene managerFrameScene = new Scene(managerFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        managerFrameScene.getStylesheets().add(css);
        // end css resource
        Stage getManagerFrame = (Stage) ((Node) event.getSource()).getScene().getWindow();
        getManagerFrame.setScene(managerFrameScene);
        getManagerFrame.show();
    }
    
    // writes info to file when the first assigned task hyperlink is clicked
    @FXML
    private void handleAssign1(ActionEvent event) throws IOException {
        
        File storedData = new File("Tasks.txt"); // update the tasks psuedo database text file
        
        // information taken from GUI elements (text fields, combo box)
        String storedTask1;
        String storedDate1;
        String assignedEmployee1;
        
        // update infor variables with element info
        storedTask1 = task1.getText();
        storedDate1 = date1.getEditor().getText();
        assignedEmployee1 = selectEmployee.getValue().toString();
        
        // validate input
        if(selectEmployee.getSelectionModel().isEmpty()) {
            notification1.setText("Something went wrong: Please select an employee");
        }
        if(task1 == null || storedTask1.equals("") || storedDate1 == null || storedDate1.equals("")) {
            notification1.setText("Something went wrong: Please fill out all fields");
        }
        else { // good input, write to file
            try {
                FileWriter data = new FileWriter(storedData, true); // this is the file
                BufferedWriter storeData = new BufferedWriter(data); // this is the writer
                // each new piece of info is stored on a new line
                storeData.append(storedDate1); // date of task is line 1
                storeData.newLine();
                storeData.append(assignedEmployee1); // user is line 2
                storeData.newLine();
                storeData.append(storedTask1); // task info is line 3
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace(); // no extra handler necessary
            }
            
            // set label so user knows task has been created
            notification1.setText("Task successfully created");
            notification1.setTextFill(Color.web("#ffffff")); // make label text white
            
            // reset tht text fields and text areas
            task1.setText(null);
            date1.getEditor().setText(null);
        }
    }
    
    // handler for when the second assign task hyperlink is selected
    @FXML
    private void handleAssign2(ActionEvent event) throws IOException {
        File storedData = new File("Tasks.txt"); // update task file
        
        // info stored from GUI elements
        String storedTask2;
        String storedDate2;
        String assignedEmployee2;
        
        // getting information from GUI elements
        storedTask2 = task2.getText();
        storedDate2 = date2.getEditor().getText();
        assignedEmployee2 = selectEmployee2.getValue().toString();
        
        // validate input
        if(selectEmployee2.getSelectionModel().isEmpty()) {
            notification2.setText("Something went wrong: Please select an employee");
        }
        if(task2 == null || storedTask2.equals("") || storedDate2 == null || 
                storedDate2.equals("")) {
            notification2.setText("Something went wrong: Please fill out all fields");
        }
        else { // good input, write to file
            try {
                FileWriter data = new FileWriter(storedData, true); // this is the file
                BufferedWriter storeData = new BufferedWriter(data); // this is the writer
                // each piece of data is stored on a new line
                storeData.append(storedDate2); // the date of the second task
                storeData.newLine();
                storeData.append(assignedEmployee2); // user for second task
                storeData.newLine();
                storeData.append(storedTask2); // info for second task
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            }
            
            // update label text to let user know task was a success
            notification2.setText("Task successfully created");
            notification2.setTextFill(Color.web("#ffffff")); // set label color to white
            
            // reset the text fields and text areas
            task2.setText(null);
            date2.getEditor().setText(null);
        }
    }
    
    // handler for when the third hyperlink for assigning a task is selected
    @FXML
    private void handleAssign3(ActionEvent event) throws IOException {
        
        File storedData = new File("Tasks.txt"); // this is the file to update
        
        // info from the GUI elements to be stored and writte
        String storedTask3;
        String storedDate3;
        String assignedEmployee3;
        
        // getting the info from the GUI elements and updating vars
        storedTask3 = task3.getText();
        storedDate3 = date3.getEditor().getText();
        assignedEmployee3 = selectEmployee3.getValue().toString();
        
        // validate input
        if(selectEmployee3.getSelectionModel().isEmpty()) {
            notification3.setText("Something went wrong: Please select an employee");
        }
        if(task3 == null || storedTask3.equals("") || storedDate3 == null || 
                storedDate3.equals("")) {
            notification3.setText("Something went wrong: Please fill out all fields");
        }
        else { // good input, write to file
            try {
                FileWriter data = new FileWriter(storedData, true); // file to write
                BufferedWriter storeData = new BufferedWriter(data);
                storeData.append(storedDate3); // date of third task
                storeData.newLine();
                storeData.append(assignedEmployee3); // user for third task
                storeData.newLine();
                storeData.append(storedTask3); // info for third task
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            }
            
            notification3.setText("Task successfully created");
            notification3.setTextFill(Color.web("#ffffff"));
            
            // reset the text fields and text areas
            task3.setText(null);
            date3.getEditor().setText(null);
        }
    }
    
    // run this method everytime the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // read from employee data to figure out what to put in the combo boxes
        File storedDataEmployee = new File("StoredDataEmployee.txt");
        
        String lineFind; // line variable used for reading through the file
        try {
            // file to read from and corresponding buffered reader
            FileReader readEmpData = new FileReader(storedDataEmployee);
            BufferedReader readEmployeeData = new BufferedReader((readEmpData));
            
            // read until file is empty (first line is a valid username)
            while((lineFind = readEmployeeData.readLine()) != null) {
                // add first valid username to arraylist
                employees.add(new String(lineFind)); // add every other line to arraylist
                lineFind = readEmployeeData.readLine(); // skip next line
            }
            
        } catch(Exception e) {
            System.out.println(e); // further handler necessary
        }
        
        // add the employee usernames to the combo boxes
        selectEmployee.getItems().addAll(employees);
        selectEmployee2.getItems().addAll(employees);
        selectEmployee3.getItems().addAll(employees);
    }    
}
