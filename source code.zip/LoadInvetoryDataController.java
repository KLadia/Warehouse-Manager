/* 
 * I DID NOT SPELL INVENTORY CORRECTLY PLEASE MAKE NOTE
 * loadinvetorydatacontroller.java
 *
 * This frame is accessed by the manager from the inventory tab 'load inventory data'
 * hyperlink. It allows the manager to start a new inventory by entering components
 * and the number of items in a new compoenent. The manager can also access previously
 * loaded components to mark items within them as completed. This information is
 * written to the file inventory.txt or inventorycompleted.txt. The manager can also 
 * access the approval frame for clearing inventory data from here.
 *
 * @author : chelseaatkins (Nov 30 2017)
 *
 * @SQA    : kristinladia (last tested Dec 1 2017)
 *
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class LoadInvetoryDataController implements Initializable {
    
    String newComponent;
    String newItems;
    
    String completedComponent;
    String completedItems;
    
    static String date; // used for getting the date last updated
    
    @FXML
    private Label notificationTop; // notification for adding a new component and items
    
    @FXML
    private Label notificationBottom; // notification for completing items
    
    @FXML
    private TextField compNew; // text field for adding new component
    
    @FXML
    private TextField itemsnew; // text field for adding items in a component
    
    @FXML
    private ComboBox compComplete; // combo box with components in it
    
    @FXML
    private TextField itemsComplete; // text field to add completed items
    
    // handler for entering a new component with items
    @FXML
    private void handleNew(ActionEvent event) throws IOException {
        
        // information from GUI components
        newComponent = compNew.getText();
        newItems = itemsnew.getText();
        
        // validating user input
        if(!newComponent.startsWith(" ") && !newItems.startsWith(" ") && 
                !newComponent.equals("") && !newItems.equals("")) {
            
            // reset text fields
            compNew.setText(null);
            itemsnew.setText(null);
            
            try {
                // these are for writing to the inventory data file
                FileWriter data = new FileWriter(new File("Inventory.txt"), true);
                BufferedWriter storeData = new BufferedWriter(data);
                
                // add the component name on a new line
                storeData.append(newComponent);
                storeData.newLine();
                storeData.append(newItems); // next line stored number of items
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace();
            } // end try-catch for writing new inventory components
            
            // get the current time of update for
            Calendar cal = Calendar.getInstance();
            date = cal.getTime().toString(); // get update to string
            
        }
        // if we're here then something wasn't right in the input validation
        else {
            
            // set the label text with error message
            notificationTop.setText("Something went wrong");
            notificationTop.setTextFill(Color.RED); // change color to red
        }
    }
    
    // handler for whent he user marks certain items within as component as complete
    @FXML
    private void handleComplete(ActionEvent event) throws IOException {
        
        // these are the information stored form the GUI
        String completedComp = compComplete.getValue().toString();
        String completedItem = itemsComplete.getText();
        
        // validating user input
        if(!completedItem.startsWith(" ") && !(compComplete.getSelectionModel().isEmpty()) && 
                !completedItem.equals("")) { // this means everything is good
            
            // clear text box
            itemsComplete.setText(null);
            
            try { // begin writing inventory information to file
                
                // this is the file to write to
                FileWriter data = new FileWriter(new File("InventoryCompleted.txt"), true);
                BufferedWriter storeData = new BufferedWriter(data);
                
                storeData.append(completedComp); // put the complete component name on a line
                storeData.newLine();
                storeData.append(completedItem); // new line stored the number of items completed
                storeData.newLine();
                storeData.close(); // close writer
            } catch (IOException e) {
                e.printStackTrace(); // no further handler necessary
            } // end try-catch for completing inventory items
            
            // set label text with success message
            notificationBottom.setText("Success");
            notificationBottom.setTextFill(Color.WHITE); // make label white
        }
        // if we get here then there was an error somewhere
        else {
            // set label text with error message
            notificationBottom.setText("Something went wrong");
            notificationBottom.setTextFill(Color.RED); // make label red
        }
    }
    
    // for showing approval for inventory popup
    @FXML
    private void handleClear(ActionEvent event) throws IOException {
        // create popup (are you sure you want to clear inventory data?)
        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        Parent createLabelFrame = FXMLLoader.load(getClass().getResource("ApproveInventoryRemoval.fxml"));
        Scene createLabelScene = new Scene(createLabelFrame);
        // @daniela : add css style sheet
        String css = WarehouseManagementSystem.class.getResource("StyleSheet.css").toExternalForm();
        createLabelScene.getStylesheets().add(css);
        // end css resource
        dialog.setScene(createLabelScene);
        dialog.show();
    }
    
    
    // execute this method everytime the window is refreshed
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // populate the combo box of components that have already been added to file        
        try{
            // file to read from to populate inventory information
            FileReader readInventory = new FileReader(new File("Inventory.txt"));
            BufferedReader readData = new BufferedReader((readInventory));
            
            String line; // used for reading through file
            
            // temporarily stores all components from file
            List<String> temp = new ArrayList<String>();
            
            while((line = readData.readLine()) != null) { // reading through file
                temp.add(new String(line)); // add each line in the file to array list
                line = readData.readLine(); // skip the line with number of items
            }
            
            // add the completed inventory components to the combobox
            compComplete.getItems().addAll(temp);
            
        } catch(Exception e) {
                System.out.println(e); // no further handler necesary
        } // end try-catch for reading inventory file
    } // end initialize method 
}
