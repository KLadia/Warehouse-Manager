/* 
 * viewallannouncementscontroller.java
 *
 * This is the class that controls the popup for viewing all the announcements.
 * It features a scrollbar to view all the announcements.
 *
 * @author : chelseaatkins (Oct 21 2017)
 *
 * @SQA    : kristinladia (last tested on Oct 22) 
 * 
 */

package warehousemanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;

public class ViewAllAnnouncementsController implements Initializable {
    
    @FXML
    private Label announcements; // label for setting the text of the announcements
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // this is the file to read from
        File AnnouncementsData = new File("Announcements.txt");
        
        try{
            // readers for looping through the lines in the file
            FileReader readAnnouncements = new FileReader(AnnouncementsData);
            BufferedReader readData = new BufferedReader((readAnnouncements));
            
            // variable for reading through lines in the file
            String lineFind;
            
            // vairable used for storing the announcement information
            // will be concatenated later
            String storeAnnouncements = "";
            
            // array list for temporarily storing announcement information
            List<String> temp = new ArrayList<String>();
            
            // loop through all lines in the file until null
            while((lineFind = readData.readLine()) != null) {
                
                // add lines from file to the temporary array list
                temp.add(lineFind);
            }
            
            // read through array list backwards
            for(int i = temp.size() - 1; i >= 0; i--) {
                // put most recent announcement at the top
                storeAnnouncements += (temp.get(i) + System.lineSeparator() + System.lineSeparator());
                // set announcement label text to display text
                announcements.setText(storeAnnouncements);
            }
        } catch(Exception e) {
                System.out.println(e); // no further handler necessary
        } // end try-catch for reading through announcements.txt
    } // end initialize method
}
